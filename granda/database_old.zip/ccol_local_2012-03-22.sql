# Sequel Pro dump
# Version 2492
# http://code.google.com/p/sequel-pro
#
# Host: 127.0.0.1 (MySQL 5.5.9)
# Database: ccol_local
# Generation Time: 2012-03-22 03:25:00 -0700
# ************************************************************

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table catering
# ------------------------------------------------------------

DROP TABLE IF EXISTS `catering`;

CREATE TABLE `catering` (
  `idCatering` int(80) NOT NULL AUTO_INCREMENT,
  `cateringName` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `cateringDesc` text COLLATE utf8_unicode_ci NOT NULL,
  `cateringImg` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cateringPrice` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `cateringStatus` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `idcateringfullCat` int(10) NOT NULL,
  PRIMARY KEY (`idCatering`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `catering` WRITE;
/*!40000 ALTER TABLE `catering` DISABLE KEYS */;
INSERT INTO `catering` (`idCatering`,`cateringName`,`cateringDesc`,`cateringImg`,`cateringPrice`,`cateringStatus`,`idcateringfullCat`)
VALUES
	(12,'MEDITERRANEAN ','SOUVLAKI STICKS \r\nGreek style seasoned Chicken and Steak skewers\r\nMEDITERRANEAN GARDEN SALAD\r\nFRESH GREEK SALAD with FETA CHEESE\r\nTZAZZIKI DIPPING\r\nHUMUS & PITTA BREAD\r\n','img_2012221416588.jpg','14.95','',6),
	(14,'SUPER TACO BAR','CHICKEN, STEAK or SHRIMP FAJITAS \r\nWHITE or MEXICAN RICE \r\nBLACK or PINTO BEANS \r\nFLOUR TORTILLAS  \r\nSALSA&SALAD BAR: fresh salsa, pico de gallo, cheese, lettuce   \r\nGUACAMOLE, SOUR CREAM, and CORN CHIPS  \r\n','img_20122214165836.jpg','12.95','',6),
	(15,'CHICKEN PARMIGIANA','TENDER CHICKEN BREAST - PARMIGIANA STYLE\r\nPENNE PASTA with GRILLED VEGGIES & MARINARA  \r\nGARLIC BREAD \r\nCAESAR or GREEN SALAD \r\n(please specify salad selection in the box below)\r\nCHOCOLATE CHIP COOKIES','img_2012221416593.jpg','12.95','',6),
	(16,'SANDWICH MIX','ASSORTED SANDWICHES \r\nplease make sandwich selection from our Catering Menu and enter it in the box below \r\nPASTA CAPRESE or ORZO PASTA SALAD (specify below)\r\nGREEN or CAESAR SALAD (specify below)\r\nCHOCOLATE CHIP COOKIES \r\n','img_201221132054.jpg','12.95','',3),
	(17,'ASSORTED WRAPS ','ASSORTED WRAPS \r\nmake your own wrap selection, choose from our Catering Menu and enter it in the box below \r\nPASTA CAPRESE or ORZO PASTA SALAD \r\nGREEN or CAESAR SALAD (specify Salad selection below)\r\nCHOCOLATE CHIP COOKIES \r\n','img_201221132142.jpg','11.95','',4),
	(18,'FRUIT & PASTRY BUFFET','Light and refreshing Breakfast option\r\nLOW-FAT YOGURT (vanilla or strawberry flavor) \r\nFRESH FRUIT & BERRIES MIX served with ORGANIC GRANOLA \r\nASSORTED PASTRY PLATTER \r\n(please specify pastry selection below) \r\nCOFFEE (served with condiments)','img_2012211314224.jpg','12.95','',1),
	(19,'POWER BREAKFAST BUFFET','SCRAMBLED EGGS\r\nBREAKFAST STYLE POTATOES\r\nBACON, HAM or SAUSAGE \r\n(please specify meat selection below)\r\nBREAKFAST BREADS with condiments, or TORTILLAS and salsa\r\nFRESHLY SQUEEZED ORANGE JUICE and COFFEE \r\n','img_2012221417131.jpg','12.95','',1),
	(20,'BREAKFAST CONTINENTAL STYLE ','ASSORTED PASTRY PLATTER and PRESERVES\r\n(please select from Full Catering Menu page and enter in box below)\r\nFRESHLY SLICED FRUITS \r\nMINI PARFAITS\r\nCOFFEE & ORANGE JUICE \r\nserved with all condiments','img_2012211315215.jpg','10.75','',1);

/*!40000 ALTER TABLE `catering` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table cateringAddons
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cateringAddons`;

CREATE TABLE `cateringAddons` (
  `idCateringAddons` int(20) NOT NULL AUTO_INCREMENT,
  `cateringAddonsTitle` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cateringAddonsPrice` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `cateringAddonsType` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idCateringAddons`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `cateringAddons` WRITE;
/*!40000 ALTER TABLE `cateringAddons` DISABLE KEYS */;
INSERT INTO `cateringAddons` (`idCateringAddons`,`cateringAddonsTitle`,`cateringAddonsPrice`,`cateringAddonsType`)
VALUES
	(24,'Diet Coke','+0.90','beverges'),
	(23,'Coke','+0.90','beverges'),
	(21,'FIJI Water','+1.35','beverges'),
	(22,'Orange Juice 12oz','+1.35','beverges'),
	(19,'Whole Fruits','+1.00','dessert'),
	(20,'Bottled Water','+0.90','beverges'),
	(17,'Cheese Cake w/trimming','+1.95','dessert'),
	(18,'Chocolate Brownies','+1.25','dessert'),
	(16,'Cheese Cake','+1.50','dessert'),
	(15,'Lemon Cake ','+1.50','dessert'),
	(25,'Sprite ','+0.90','beverges'),
	(26,'Sprite - Diet (12oz)','+0.90','dessert'),
	(27,'Gatorade','1.89','beverges'),
	(28,'Vitamin Water','+1.89','beverges');

/*!40000 ALTER TABLE `cateringAddons` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table cateringfullCat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cateringfullCat`;

CREATE TABLE `cateringfullCat` (
  `idcateringfullCat` int(5) NOT NULL AUTO_INCREMENT,
  `cateringfullCatName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cateringfullCatDesc` text COLLATE utf8_unicode_ci NOT NULL,
  `cateringfullCatImg1` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cateringfullCatImg2` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cateringfullCatImg3` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idcateringfullCat`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `cateringfullCat` WRITE;
/*!40000 ALTER TABLE `cateringfullCat` DISABLE KEYS */;
INSERT INTO `cateringfullCat` (`idcateringfullCat`,`cateringfullCatName`,`cateringfullCatDesc`,`cateringfullCatImg1`,`cateringfullCatImg2`,`cateringfullCatImg3`)
VALUES
	(1,'BREAKFAST','','','',''),
	(2,'APPETIZERS','','','',''),
	(3,'SANDWICH SELECTION','Served with 2 salads of your choice, chips and cookies $11.95 /person','','',''),
	(4,'WRAPS','','','',''),
	(5,'SALAD SELECTION - CATERING','','','',''),
	(6,'ENTRÉES ','','','','');

/*!40000 ALTER TABLE `cateringfullCat` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table cateringfullItem
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cateringfullItem`;

CREATE TABLE `cateringfullItem` (
  `idcateringfullItem` int(100) NOT NULL AUTO_INCREMENT,
  `cateringfullItemName` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `cateringfullItemDesc` text COLLATE utf8_unicode_ci NOT NULL,
  `idcateringfullCat` int(30) NOT NULL,
  `cateringfullItemStatus` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cateringfullItemPrice` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idcateringfullItem`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `cateringfullItem` WRITE;
/*!40000 ALTER TABLE `cateringfullItem` DISABLE KEYS */;
INSERT INTO `cateringfullItem` (`idcateringfullItem`,`cateringfullItemName`,`cateringfullItemDesc`,`idcateringfullCat`,`cateringfullItemStatus`,`cateringfullItemPrice`)
VALUES
	(4,'FRESH BAKERY ASSORTMENT ','Selection of muffins, bagels, croissants, or Danish pastries and sweet breads, served with cream-cheese, butter and preserves. $5.25/person MIN. 12',1,'','5.25/p.'),
	(3,'MOTE CHRISTO BREAKFAST SANDWICH ','Served with syrup and individual fruit cups. $5.95/person MIN.12',1,'','5.95/p.'),
	(58,'HEARTY OATMEAL','Breakfast for good start! Our old-fashioned, steel-cut oatmeal is served hot with following condiments: raising, brown sugar, butter, and milk. $ 3.75/person MIN. 15',1,'',''),
	(6,'BREAKFAST SANDWICH PLATTER ','Breakfast sandwiches made on croissants or your choice of bread, in three variations: Bacon and Cheese, Ham and Cheese, and Spinach and Cheese. $4.50 each MIN.12 BUFFET STYLE SERVING with Country potatoes, butter and preserves, selection of two meats $6.95/p.',1,'','6.95/p.'),
	(7,'VEGETARIAN EGG-WHITE BREAKFAST BURRITOS','Healthy choice. Egg whites wraps made on whole wheat tortilla, you can choose from Spinach and Feta cheese, and pico de gallo, Bacon and cheese. 6.95/person MIN.12',1,'','6.95/p.'),
	(8,'BREAKFAST BURRITO PLATTER ','Flour tortillas stuffed with fluffy scrambled eggs, cheese, potatoes, and your choice of bacon, sausage, spinach, or no meat. $4.50 ea. MIN.12\r\nBUFFET STYLE OF SERVING with breakfast potatoes, pico de gallo, salsa and sour cream $6.95/person \r\n',1,'','6.95/p.'),
	(9,'FRUIT AND YOGURT PARFAIT CUPS ','Assorted low-fat yogurt, selection of fresh fruits (banana, strawberries, or blueberries) topped with organic granola. $5.25/person \r\nBUFFET STYLE – served separately, with 3 choices of fruit, and individual fruit cups (CAN ONLY BE ORDERED AS ADDITION TO ANY OTHER ITEM)\r\n',1,'','5.25/p.'),
	(10,'ARTISAN CHEESE and FRUIT PLATES ','Beautifully arranged Baby Brie, Swiss Ementaller, Mozzarella, Sharp Cheddar, and Apple Jack cheeses, with red and white grapes, organic green apples, and other fresh sliced fruits, served with assorted nuts and crackers. $ 11.95/person MIN.12',2,'','11.95/p.'),
	(11,'SLICED MEATS PARTY PLATTER ','Selection of Prosciutto, Deli corned beef, Smoked Turkey Breas, Italian salami and fresh cucumber, served with pickles, green olives, and cherry tomato. $12.95/person',2,'','12.95/p.'),
	(12,'CRUDITE PLATTER (SLICED FRESH VEGETABLES) ','Fresh vegetables, sliced and garnished, with side of Ranch dip.  $3.95/person (CAN ONLY BE ORDERED AS ADDITION TO OTHER ITEM) ',2,'','3.95/p.'),
	(13,'FRESH FRUIT PLATTER  ','Fresh fruits, sliced and garnished, with side of caramelized vanilla dip.  $3.95/person (CAN ONLY BE ORDERED AS ADDITION TO OTHER ITEM) ',2,'','3.95/p.'),
	(57,'MEDITERRANEAN APPETIZER','You will love it… Humus, Tzazziki (Greek yogurt with cucumber & mint), and Dulmas(stuffed grape leafs) served with pitta chips and kalamata olive pesto $4.95/person MIN 20',2,'',''),
	(15,'CHICKEN SATAY ','Lightly spicy marinated Chicken breasts sticks, served with traditional Thai peanut sauce, with side of steamed rice. $4.95/person MIN. 20',2,'','4.95/p.'),
	(16,'SHRIMP COCKTAIL ','This party essential comes on platter with delicious house-made sauce. It could be served on martini glasses if desired. 6.95/person MIN.15',2,'',''),
	(17,'ALBACORE TUNA-SALAD SANDWICH','Albacore tuna-salad mix with celery, olives, pickles, mayonnaise, white pepper and slightly salted',3,'',''),
	(18,'CHICKEN-SALAD SANDWICH','Tender Chicken breast mixed with mayonnaise, celery, apples, cranberries, plus lettuce and tomato, on your choice of bread ',3,'',''),
	(19,'CALIFORNIA CLUB with AVOCADO','Sliced smoked turkey breast, avocado, tomato, lettuce, hint of red onion, crumbles of bacon, Swiss cheese, and ranch dressing spread; Recommended choice of bread – croissant ',3,'',''),
	(20,'SMOKED TURKEY & SWISS','Smoked Turkey breasts sliced, Swiss cheese, green leaf lettuce, onion, tomato, mustard and mayo, on your choice of bread ',3,'',''),
	(21,'BLT with AVOCADO','Bacon, lettuce, tomato, with avocado, mayonnaise and Dijon mustard spread; your choice of bread ',3,'',''),
	(22,'HAM & CHEESE','Sliced honey ham, cheddar cheese, tomato, Iceberg lettuce, pickles, mustard and mayonnaise ',3,'',''),
	(23,'ROAST BEEF ','Slow-roasted beef, pickles, tomato, provolone and cheddar cheese, horseradish, green leaf lettuce, mustard and mayo ',3,'',''),
	(24,'CLASSIC ITALIAN','Ham, Italian Salami, pepperoni, sliced pepperoncini, pickles, red onion, provolone cheese, bell peppers, tomato, shredded iceberg lettuce, mustard and mayonnaise ',3,'',''),
	(25,'CAPRESE TOMATO MOZZARELLA SANDWICH (Vegetarian)','Sliced fine ripe steak-tomatoes, fresh basil leafs, baby spinach leafs, and soft mozzarella cheese; oregano, olive oil-balsamic vinaigrette drizzle ',3,'',''),
	(26,'GRILLED VEGGIE SANDWICH','Grilled veggies: red bell pepper, yellow squash, asparagus, red onion, provolone cheese, cilantro pesto spread, spinach leafs ',3,'',''),
	(27,'GRILLED CHICKEN SANDWICH','Grilled Chicken, bell peppers, sun dried tomato, green lettuce leafs, Cilantro-Pesto with mayo and balsamic vinegar spread; your choice of bread',3,'',''),
	(28,'CHICKEN-SALAD WRAP','Our delicious chicken salad mix, green leafs, sprouts, and orange hearts, wrapped tortilla of your choice ',4,'',''),
	(29,'AVOCADO-VEGGIE WRAP','Avocado, green leaf lettuce, cucumber, tomato, sliced bell pepper, shredded carrots, alfalfa sprouts, cilantro, olive oil drizzled; recommended in spinach or sundried tomato wrap, your choice of Ranch, humus, or other sauces on the side',4,'',''),
	(30,'CHICKEN CAESAR WRAP','Grilled chicken, romaine lettuce, hint of red onion, parmesan cheese, bacon, crunched croutons; served with creamy Caesar dipping sauce on the side',4,'',''),
	(31,'SPICY THAI GRILLED CHICKEN WRAP ','Thai grilled chicken breasts, green leaf lettuce, tomato, cucumber, shredded carrot, bean sprouts, cilantro, served with Thai-peanut dipping sauce and sesame-ginger on the side',4,'',''),
	(32,'SOUTH WESTERN STYLE WRAP','Grilled chicken, roasted corn, black beans, sliced pepper jack cheese, shredded mozzarella cheese, green leaf lettuce, cucumber, tomato; served with Southwestern sauce on the side, and your choice of tortilla flavor (recommended: on sundried tomato tortilla)',4,'',''),
	(34,'TURKEY and CREAM-CHEESE CUT WRAPS','Sliced smoked turkey, cucumber, carrots, cream cheese spread, green leafs, served with ranch ',4,'',''),
	(35,'SPRING ROLLS ','Chicken or Shrimp, with Avocado; cucumber, rice noodles, bean sprouts, lettuce, cilantro, wrapped in rice paper; served with hot-sauce, sesame-ginger soy sauce, and Thai-peanut sauce on the side',4,'',''),
	(37,'ORGANIC GREEN','\r\nOrganic baby spring mix, sliced young cucumber, and green onion, served seasoned with olive oil, salt and pepper, or tossed with servings upon delivery\r\n',5,'',''),
	(38,'CRISPY CAESAR ','\r\nFresh cut crispy Romaine lettuce, croutons, and parmesan cheese with dressing on the side\r\n',5,'',''),
	(39,'ANTIOXIDANT','\r\nBaby spring mix, fresh blueberries, dried cranberries, strawberries, apples, fresh mint leafs, red onion, cucumbers, blue cheese, served with vanilla bean balsamic vinaigrette dressing\r\n',5,'',''),
	(40,'CHOPPED GREEK GARDEN SALAD','\r\nSliced fresh cucumber, tomatoes, black olives, artichoke hearts, Italian parsley, Feta cheese, lemon juice, black pepper, extra virgin olive oil, over a bedding of Organic green mix\r\n',5,'',''),
	(41,'FRESH MEDITERRANEAN SALAD (WITH CUBES OF FETA CHEESE)','Diced fresh cucumber, tomatoes, bell pepper, green olives, artichoke hearts, Feta cheese, lemon juice, extra virgin olive oil (The way salad is made and served, it doesn’t need dressings)\r\n',5,'',''),
	(43,'TANGARINE HARTS - ORIENTAL STYLE SALAD','\r\nFresh iceberg lettuce, Napa cabbage, red cabbage, edamame, carrot, green onion, cilantro, rice noodle; served with Oriental sesame ginger dressing on the side\r\n',5,'',''),
	(44,'ANGEL HAIR – PASTA SALAD','\r\nAngel hair pasta, mixed with diced roma tomatoes, fresh basil, feta and Parmesan cheese, and tossed with extra virgin olive oil\r\n',5,'',''),
	(45,'CAPRESE PASTA SALAD','\r\nPenne pasta mixed with cut cherry tomatoes, fresh basil leafs, fresh mozzarella, seasoned and mixed with olive oil\r\n',5,'',''),
	(46,'ORZO PASTA SALAD ','\r\nOrzo pasta, asparagus, bell pepper, Italian parsley, parmesan cheese, red onion, tossed in virgin olive oil\r\n',5,'',''),
	(47,'TRI-PASTA ROTINI - ITALIAN STYLE','\r\nRotini pasta, sliced olives, onion, bell pepper, seasoned and tossed in olive oil\r\n',5,'',''),
	(48,'CHICKEN PARMESAN','Tender chicken breasts in bread crumbles, marinara sauce over penne pasta, garlic bread',6,'',''),
	(49,'BOW TIE PASTA ALFREDO WITH CHICKEN or VEGETARIAN','Bow tie pasta in white Alfredo sauce, mixed with chicken slices and vegetables',6,'',''),
	(50,'PASTA WITH GRILLED VEGGIES IN MARINARA SAUCE (Vegetarian)','This pasta option is vegetarian, and it comes with your choice of pasta, with veggie-marinara sauce',6,'',''),
	(51,'KUNG PAO CHICKEN','Kung-pao seasoned chicken, with peanuts, Thai chili and, lemon grass, onion, and seasoning; served with rice on the side',6,'',''),
	(52,'TERYAKI CHICKEN, STEAK, or SALMON','Teryaki glazed Chicken, Steak, or Salmon, served over rice and steamed vegetables',6,'',''),
	(53,'MONGOLIAN BEEF','Fine sliced steak, marinated and grilled with soy garlic-sauce and served with sides of steamed rice and broccoli, or other vegetables by your choice',6,'',''),
	(54,'CHICKEN & STEAK SOUVLAKI','Greek style seasoned Chicken and Steak skewers, served with Mediterranean sides and appetizers ',6,'',''),
	(55,'SUPER TACO BAR','Chicken, steak, or shrimp Fajitas -steamed white or Mexican rice  -pinto or black beans  -salsa bar: fresh salsa, pico de gallo, grated cheese, fresh cut lettuce -corn chips, guacamole, and sour cream -corn and flour tortill',6,'','');

/*!40000 ALTER TABLE `cateringfullItem` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table cateringText
# ------------------------------------------------------------

DROP TABLE IF EXISTS `cateringText`;

CREATE TABLE `cateringText` (
  `idCatTxt` int(5) NOT NULL AUTO_INCREMENT,
  `catTitle` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `catTxt` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `catTitleShrt` int(10) NOT NULL,
  `catTxtShrt` int(10) NOT NULL,
  PRIMARY KEY (`idCatTxt`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

LOCK TABLES `cateringText` WRITE;
/*!40000 ALTER TABLE `cateringText` DISABLE KEYS */;
INSERT INTO `cateringText` (`idCatTxt`,`catTitle`,`catTxt`,`catTitleShrt`,`catTxtShrt`)
VALUES
	(3,'WELCOME TO CCOL GROUP ORDERS & CATERING SERVICES','We carefully created these 8 pre-selected packages, and we are now offering them at your convenience for fast and easy on-line ordering. And not just that we hope to save you some time and money, but we guaranty that most of them are the best deal in town. \r\nIn case that you would like to place a custom order please go to <a href=\"index.php?page=catering-full-menu\">Full Catering Menu</a> page, to see our full catering offer, and give us a call any time at 949-945-7702. Also use this page to customize your on-line orders. <br /><br />\r\nTHANK YOU FOR CHOOSING CORPORATE CATERING ONLINE!\r\n<br />\r\n<br />',15,170),
	(2,'WELCOME TO CCOL! ENJOY THE FUSION OF WORLD WIDE CUISINES, ALL AT ONE PLACE...','Per your request we can make you anything. You name it! Our Catering Menu features and consists of simple snacks and sandwiches, or world most popular dishes and cuisines. You can choose from: Breakfast and Appetizers, to Asian, All American, Italian, Mexican, Mediterranean, plus variety of Salads, Sandwiches, Wraps, or custom cooked meals are available as well. Our Chefs and cooks use only the best and the freshest ingredients, and organic or locally grown produce and products. We always follow the #1 rule in the kitchen: Only high quality and fresh ingredients could be used to prepare good food.  \r\n<br /><br />\r\nHowever, we don\'t want to overwhelm you with some book-like, long written and listed menu. Therefore, we would like to highly recommend some of the items bellow, that are specially created for Corporate Events and needs. We exclusively created breakfast and lunch selections, and just by entering the number of people your order is placed. Besides that, we  guaranty that some of these preselected packages are the best deal in town.\r\n',16,170);

/*!40000 ALTER TABLE `cateringText` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table company
# ------------------------------------------------------------

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `idComp` int(100) NOT NULL AUTO_INCREMENT,
  `companyName` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `adress` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `suite` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `zipCode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `contactPerson` text COLLATE utf8_unicode_ci NOT NULL,
  `deliveryTime` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `deliveryTime2nd` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idComp`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` (`idComp`,`companyName`,`adress`,`city`,`suite`,`zipCode`,`contactPerson`,`deliveryTime`,`deliveryTime2nd`)
VALUES
	(1,'Nesk WebArt','Dolcevita Investments Holding Inc.','Road Town, Tortola, British Virgin Islands','15/21','43169','Daniel Dulic,\r\n+3816412345678','09:30 AM - 21:20 PM','14:20'),
	(5,'Corporate Catering Online','17821 Sky Park Circle','Irvine','A','92614','Grada Lukic','09:20 AM - 09:35 AM',''),
	(7,'Ricoh','13224 Warner Avenue','Tustin','100','92345','linda','08:30 AM - 08:45 AM','12:30 PM - 12:45 PM');

/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table coupons
# ------------------------------------------------------------

DROP TABLE IF EXISTS `coupons`;

CREATE TABLE `coupons` (
  `idcoupons` int(240) NOT NULL AUTO_INCREMENT,
  `couponID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `couponStart` date NOT NULL,
  `couponExp` date NOT NULL,
  `couponAmount` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `couponAct` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `couponType` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idcoupons`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` (`idcoupons`,`couponID`,`couponStart`,`couponExp`,`couponAmount`,`couponAct`,`couponType`)
VALUES
	(1,'cx2387b','2012-03-01','2012-04-01','3.00','','absolute'),
	(2,'expired','2012-01-01','2012-01-31','10','0','absolute'),
	(3,'inactive','2012-03-01','2012-03-31','10','1','absolute'),
	(4,'percent','2012-03-01','2012-03-31','10','0','percent'),
	(5,'absolute','2012-03-01','2012-03-31','10','0','absolute');

/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table dropDown
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dropDown`;

CREATE TABLE `dropDown` (
  `idDropDown` int(20) NOT NULL AUTO_INCREMENT,
  `dropDownName` varchar(100) NOT NULL,
  `position` varchar(10) NOT NULL,
  `showPrizes` enum('show','hide') NOT NULL,
  `showQty` enum('show','hide') NOT NULL,
  `displayIn` text NOT NULL,
  PRIMARY KEY (`idDropDown`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

LOCK TABLES `dropDown` WRITE;
/*!40000 ALTER TABLE `dropDown` DISABLE KEYS */;
INSERT INTO `dropDown` (`idDropDown`,`dropDownName`,`position`,`showPrizes`,`showQty`,`displayIn`)
VALUES
	(1,'Whole Fresh Fruit','3','show','show','100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 61, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 116, 115, 114, 112, 111, 62, 60, 10, 8, 7, 6, 5, 4'),
	(3,'or Chips &amp; Snacks','6','show','show','100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 61, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 116, 115, 114, 112, 111, 62, 60, 10, 8, 7, 6, 5, 4'),
	(4,'or Sweets','4','show','show','100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 61, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 116, 115, 114, 112, 111, 62, 60, 10, 8, 7, 6, 5, 4'),
	(5,'And Drinks','5','show','show','100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 110, 109, 108, 107, 106, 105, 104, 103, 102, 101, 61, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 116, 115, 114, 112, 111, 62, 60, 10, 8, 7, 6, 5, 4'),
	(6,'Dressing choices','1','hide','hide','100, 99, 98, 97, 96, 95, 94, 93, 92, 91, 90, 89, 87, 86, 85, 84, 83, 82, 110, 109, 108, 107, 106, 105, 104, 103'),
	(7,'Lettuce Choices','2','hide','hide','98, 96, 95, 94, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 110, 109, 107, 106, 105, 104'),
	(8,'Tortilla choices','1','hide','hide','116, 115, 114, 112, 111, 62, 5, 4'),
	(9,'Meat Choices','2','hide','hide','6, 5, 4'),
	(10,'Bread choices','1','hide','hide','61, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 6'),
	(11,'Add sides','2','show','show','61, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 43, 42, 116, 115, 114, 112, 111, 62, 60, 6'),
	(12,'Choose yogurt flavor ','1','hide','hide','8, 7'),
	(13,'Choose berries','2','hide','hide',''),
	(14,'Choose your pastry','1','show','show','10'),
	(15,'Choose trimmings','2','show','show','10'),
	(20,'Berry Choices','2','hide','hide','8, 7'),
	(17,'Spring Roll Choices','1','show','hide','60'),
	(18,'Meat or Fish Choice','2','show','show','100, 99, 97, 88'),
	(19,'Dipping Sauces ','2','hide','hide','81, 102, 101');

/*!40000 ALTER TABLE `dropDown` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table dropDownItems
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dropDownItems`;

CREATE TABLE `dropDownItems` (
  `idItemDropDown` int(210) NOT NULL AUTO_INCREMENT,
  `dropDownItemName` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `idDropDown` int(100) NOT NULL,
  `dropDownItemPrice` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ddVisible` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idItemDropDown`)
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `dropDownItems` WRITE;
/*!40000 ALTER TABLE `dropDownItems` DISABLE KEYS */;
INSERT INTO `dropDownItems` (`idItemDropDown`,`dropDownItemName`,`idDropDown`,`dropDownItemPrice`,`ddVisible`)
VALUES
	(2,'Banana',1,'0.90','show'),
	(49,'Ranch',6,'','show'),
	(4,'Romaine lettuce',7,'','show'),
	(7,'Kettle One - Natural',3,'1.49','show'),
	(8,'Kettle One -Sea Salt & Pepper',3,'1.49','show'),
	(126,'Smart Water',5,'1.79','show'),
	(10,'Oatmeal Cookie',4,'1.35','show'),
	(11,'Chocolate Chip Cookie',4,'1.25','show'),
	(12,'Coca cola - Regular',5,'1.15','show'),
	(13,'Coca cola - Diet',5,'1.15','show'),
	(14,'Apple juice',5,'1.50','show'),
	(15,'Balsamic Vinaigrette',6,'',''),
	(110,'Fiji Apple - Organic',1,'1.39','show'),
	(109,'Green Apple -Organic',1,'1.25','show'),
	(18,'Carrot Cake (slice)',4,'2.75','show'),
	(19,'Home-made Brownie',4,'2.25','show'),
	(20,'Croissant',10,'','show'),
	(21,'Whole Wheat',10,'','show'),
	(22,'Multigrain',10,'','show'),
	(23,'Sourdough',10,'','show'),
	(24,'Country White',10,'','show'),
	(25,'Squaw',10,'','show'),
	(26,'Baguette',10,'','show'),
	(27,'Sandwich Roll',10,'','show'),
	(28,'Ciabatta',10,'','show'),
	(29,'Small Green Salad',11,'2.95','show'),
	(30,'Small Caesar Salad',11,'2.95','show'),
	(31,'Pasta Salad',11,'1.95','show'),
	(32,'Orzo Pasta Salad',11,'2.25','show'),
	(33,'Rotini Pasta Salad',11,'2.05','show'),
	(41,'Organic Spring Mix ',7,'','show'),
	(103,'White Rice',11,'1.99','show'),
	(39,'Hard Broiled Egg',11,'1.95','show'),
	(64,'Whole Wheat Tortilla',8,'','show'),
	(102,'Edamame',11,'3.50','show'),
	(104,'Brown Rice',11,'2.95','show'),
	(40,'Rye',10,'','show'),
	(42,'Organic Baby Spinach',7,'','show'),
	(43,'Iceberg ',7,'','show'),
	(44,'Iceberg-Romaine Mix',7,'','show'),
	(108,'Banana - Organic',1,'1.35','show'),
	(50,'Honey-Mustard',6,'','show'),
	(51,'Caesar (regular)',6,'','show'),
	(52,'Caesar (creamy)',6,'','show'),
	(53,'Italian',6,'','show'),
	(54,'Raspberry Vinaigrette ',6,'','show'),
	(55,'Sesame-Ginger',6,'','show'),
	(56,'Oriental',6,'','show'),
	(57,'Soy Sauce',6,'','show'),
	(59,'Kettle One - Salt & Vinegar',3,'1.49','show'),
	(60,'Kettle One - BBQ',3,'1.49','show'),
	(61,'Lays - Original',3,'1.15','show'),
	(62,'Arrowhead Bottled Water',5,'0.90','show'),
	(63,'Aqua Fina - Bottled Water',5,'1.00','show'),
	(65,'Flour Tortilla',8,'','show'),
	(66,'Spinach Tortilla',8,'','show'),
	(67,'Sundried Tomato Tortilla',8,'','show'),
	(69,'FIJI Bottled Water',5,'1.89','show'),
	(70,'Butter Croissant',14,'1.79','show'),
	(71,'Cream Cheese Croissant',14,'1.89','show'),
	(72,'Strawberry-Cream cheese Croissant ',14,'1.95','show'),
	(73,'Chocolate Croissant',14,'1.89','show'),
	(74,'Ham & Cheese Croissant',14,'2.79','show'),
	(75,'Cinnamon-Raisins Roll',14,'1.79','show'),
	(76,'Bagel - plain',14,'1.89','show'),
	(77,'Sesame Seeds Bagel',14,'1.99','show'),
	(78,'Vanilla White Vinaigrette',6,'','show'),
	(79,'Orange-Honey Vinaigrette',6,'','show'),
	(80,'Blue-cheese Dressing',6,'',''),
	(81,'Thousand Island',6,'','show'),
	(82,'Southwestern ',6,'','show'),
	(83,'Thai Peanut Dressing',6,'','show'),
	(84,'Lemon Bar',4,'2.75','show'),
	(85,'Red Velvet Cheese Cake',4,'3.25','show'),
	(86,'Tiramisu',4,'3.25','show'),
	(87,'Lays - BBQ',3,'1.15','show'),
	(88,'Everything Bagel',14,'1.99','show'),
	(89,'Cream Cheese',15,'0.50','show'),
	(90,'Butter chip',15,'0.50','show'),
	(91,'Strawberry-preserves',15,'0.50','show'),
	(92,'Apple preserves',15,'0.50','show'),
	(93,'Mixed fruit preserves',15,'0.50','show'),
	(94,'Fresh Strawberries',15,'1.25','show'),
	(95,'Fresh Blueberries',15,'1.35','show'),
	(96,'Low-fat Vanilla Yogurt',12,'','show'),
	(97,'Strawberry Yogurt',12,'','show'),
	(98,'Blueberries',13,'','show'),
	(99,'Strawberry',13,'','show'),
	(100,'Blackberries',13,'','show'),
	(101,'Plain Low-fat Yogurt',12,'','show'),
	(105,'Potato Salad',11,'2.75','show'),
	(106,'Coleslaw ',11,'2.25','show'),
	(107,'Chips & Salsa',11,'3.25','show'),
	(111,'Pear',1,'1.25','show'),
	(112,'Sweet Oranges',1,'1.25','show'),
	(113,'Fresh Strawberries',1,'3.25','show'),
	(114,'Blueberries',1,'2.75','show'),
	(115,'Grape Medley ',1,'3.75','show'),
	(116,'Pineapple ',1,'3.25','show'),
	(117,'Cantaloupe',1,'2.95','show'),
	(118,'Honey Dew',1,'3.25','show'),
	(119,'Rustic Italian',10,'','show'),
	(120,'Bacon',9,'','show'),
	(121,'Ham',9,'','show'),
	(122,'Sausage',9,'','show'),
	(123,'No meat',9,'','show'),
	(124,'Chorizo',9,'','show'),
	(125,'Cilantro-Pesto Tortilla',8,'','show'),
	(127,'Perrier',5,'1.99','show'),
	(128,'San Pellegrino',5,'1.99','show'),
	(129,'Gatorade Lemon-lime',5,'1.79','show'),
	(130,'Gatorade Fruit Punch',5,'1.79','show'),
	(131,'Gatorade - Orange',5,'1.79','show'),
	(132,'Orange Juice',5,'1.89','show'),
	(133,'Cranberry Juice',5,'1.99','show'),
	(134,'Diet COKE',5,'1.15','show'),
	(135,'Regular Coke',5,'1.15','show'),
	(136,'Grilled Chicken',17,'0','show'),
	(137,'Avocado',17,'0','show'),
	(138,'Tofu',17,'0','show'),
	(139,'Chicken-Avocado',17,'0.75','show'),
	(140,'Tofu-Avocado',17,'0.50','show'),
	(141,'Cream Cheese & LOX',15,'5.25','show'),
	(142,'Chicken Breast',18,'0','show'),
	(143,'Salmon Fillet',18,'1.25','show'),
	(144,'Shrimps',18,'1.00','show'),
	(145,'Ranch Dip',19,'','show'),
	(146,'Humus',19,'','show'),
	(147,'Caramelized Fruit Dipping',19,'','show'),
	(148,'No Dipping Souce',19,'','show'),
	(149,'Blueberries',20,'','show'),
	(150,'Blackberries',20,'','show'),
	(151,'Strawberries',20,'','');

/*!40000 ALTER TABLE `dropDownItems` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lunchbox
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lunchbox`;

CREATE TABLE `lunchbox` (
  `idLunchBox` int(20) NOT NULL AUTO_INCREMENT,
  `lunchBoxName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxDesc` text COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxImg` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxPrice` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxStatus` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxCategory` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idLunchBox`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Lunch box menu';

LOCK TABLES `lunchbox` WRITE;
/*!40000 ALTER TABLE `lunchbox` DISABLE KEYS */;
INSERT INTO `lunchbox` (`idLunchBox`,`lunchBoxName`,`lunchBoxDesc`,`lunchBoxImg`,`lunchBoxPrice`,`lunchBoxStatus`,`lunchBoxCategory`)
VALUES
	(4,'Breakfast Burritos','Scrambled eggs, potato, pico de gallo, with your choice of meat: Ham, Bacon, Steak, Sausage, Chorizo, or No meat; and tortilla flavor; for meat and tortilla choice please select from your favorite from the drop down menus.','img_20122012224936.jpg','4.25','','Breakfast'),
	(5,'Vegetarian Egg-White Burrito','Egg whites only, with Spinach & Feta cheese, Pico de Gallo and your choice of tortilla; Please choose tortilla flavor from the drop-down menu (recommended on: Whole wheat, or Sundried-tomato tortilla flavor)\r\n','img_20122012224221.jpg','6.79','','Breakfast'),
	(6,'Breakfast Sandwich','Scrambled eggs, cheddar cheese with Ham, Bacon, Sausage, or No meat (choose from the drop-down) and made on your bread choice, grilled..\r\n','img_2012201222299.jpg','4.25','','Breakfast'),
	(7,'Fruit Parfaits','Fruit & Yogurt Parfait\r\nDescription: Low-fat Yogurt, all natural granola (no raisins), and Fresh berry fruit (Choose from Vanilla, Strawberry, or Plain yogurt flavor from the drop down menu in customization window)','img_20122012223538.jpg','4.25','','Breakfast'),
	(8,'Yogurt Bircher Muesli 12oz','Description: Bircher muesli is a traditional Swiss recipe, far superior to any breakfast cereal found on the market. Ingredients: low-fat Organic yogurt, oats, cubed fruit: orange, apple, strawberry, blueberry, banana... NOTE: choose your berries and the yogurt flavor from the drop down menus','img_2012201222348.jpg','5.29','','Breakfast'),
	(10,'Fresh Bakery Assortment','Choose any pastry and trimming from customization drop-down menu: Butter croissant-plain, Ham-Cheese croissant, Chocolate croissant, Berry -cream cheese Danish, Cinnamon-roll, Apple Strudel, Bagel-plain, Bagel-sesame, and Everything- Bagel.','img_20122611224838.jpg','various','','Breakfast'),
	(42,'GRILLED CHICKEN w/CILANTRO PESTO','Grilled Chicken, bell peppers, sun dried tomato, green lettuce leafs, Cilantro-Pesto with mayo and balsamic vinegar spread; with your choice of bread ','img_20121325173240.jpg','8.95','','Sandwiches'),
	(43,'HONEY-HAM, YOUNG BRIE & DIJON MUSTARD','\r\nSliced Honey-Ham, Brie cheese, fine-cut steak tomato, pickles, mayo and Dijon mustard spread\r\n','img_20121325173357.jpg','7.95','','Sandwiches'),
	(44,'CARVED TURKEY with PESTO and CRANBERRY','\r\nCarved turkey slices, mayo pesto with sprinkles of dried cranberries, alfalfa sprouts, lettuce, tomato\r\n','img_20121325173526.jpg','6.95','','Sandwiches'),
	(45,'SLICED PEAR, BRIE & FETA CHEESE SANDWICH','\r\nOur signature dish: Grilled chicken topped with slices of Brie cheese and fresh pears, organic baby spinach leaf, and crumbles of blue cheese; Recommended on Artisan Italian Roll\r\n','img_20121325173710.jpg','7.95','','Sandwiches'),
	(46,'MEDITERRANEAN ','\r\nGrilled Ck., Feta cheese crumbles, organic baby spinach leafs, pesto sauce, oregano; always served on soft Pitta bread\r\n','img_20121325173810.jpg','6.95','','Sandwiches'),
	(47,'EASY TURKEY (Turkey & Swiss) ','\r\nSmoked Turkey Breasts, Swiss cheese, lettuce, tomato, mustard\r\n','img_20121325173858.jpg','6.75','','Sandwiches'),
	(48,'CALIFORNIA CLUB ','\r\nSmoked Turkey Breast, tomato, bacon, avocado, lettuce, with ranch dressing spread\r\n','img_20121325173953.jpg','7.95','','Sandwiches'),
	(49,'APPLE JACK','\r\nSmoked Turkey Breast, slices of apple, jalapeno jack cheese, tomato, lettuce, and with honey mustard dressing drizzle \r\n','img_2012132517416.jpg','6.95','','Sandwiches'),
	(50,'BLT  with AVOCADO','\r\nBacon, lettuce, tomato, avocado, mayonnaise and Dijon mustard spread\r\n','img_2012132517422.jpg','6.95','','Sandwiches'),
	(51,'CHICKEN-SALAD SANDWICH','\r\nTender Chicken breast mixed with mayonnaise, celery, apples, cranberries, plus lettuce and tomato on your choice of bread\r\n','img_20121325174257.jpg','6.95','','Sandwiches'),
	(52,'TUNA-SALAD SANDWICH','Albacore tuna seasoned mix with celery, mayonnaise, white pepper, salt, lettuce, served with Organic baby-spinach leafs and fresh tomato\r\n','img_20121325174347.jpg','6.95','','Sandwiches'),
	(53,'Rueben Classico',' \r\nHam, cheddar cheese, tomato, lettuce, mayonnaise\r\n','img_2012315124258.jpg','5.95','out','Sandwiches'),
	(54,'OWEN-ROASTED BEEF SANDWICH','\r\nSlow-roasted beef, lettuce, tomato, cheddar cheese, horseradish, mustard and mayo\r\n','img_20121325174552.jpg','7.95','','Sandwiches'),
	(55,'The GODFATHER','\r\nProsciutto, Mortadella, fine cut steak tomato, pepperoncini, olives, lettuce, with provolone and Mozzarella cheese on your choice of bread\r\n','img_20121325174718.jpg','7.95','','Sandwiches'),
	(56,'CLASSIC ITALIAN SANDWICH','\r\nItalian Salami, pepperoni, pepperoncini, provolone cheese, red onion, bell peppers, tomato, shredded iceberg lettuce, mayonnaise \r\n','img_20121325174817.jpg','6.95','','Sandwiches'),
	(57,'TURKEY PASTRAMI SANDWICH','\r\nTurkey pastrami with sauerkraut, pickles, Swiss cheese, Dijon mustard, and mayo; recommended on Rye bread\r\n','img_20121325175118.jpg','7.25','','Sandwiches'),
	(58,'FRESH VEGGIES w/AVOCADO','\r\nArtichokes, tomato, avocado, cucumber, bell pepper, green leaf lettuce, alfalfa sprouts, and provolone cheese\r\n','img_20121325175320.jpg','5.95','','Sandwiches'),
	(59,'CAPRESE SANDWICH (Vegetarian)','CAPRESE TOMATO MOZZARELLA (VEGETARIAN)\r\nVEGETARIAN - your choice of bread layered with ripe tomatoes, fresh basil leafs, and soft mozzarella cheese, oregano, olive oil-balsamic vinaigrette drizzle \r\n','img_20121325175445.jpg','6.95','','Sandwiches'),
	(60,'Spring Rolls','Chicken or Shrimp, with Avocado; cucumber, rice noodles, bean sprouts, lettuce, cilantro, wrapped in rice paper; served with hot-sauce, sesame-ginger soy sauce, and Thai-peanut sauce on the side\r\n(Chicken or  Avocado,  Shrimp +1.00, Ck&Av.+$1.50, Sh.& Av.+$1.50 – choose from the drop down menu)\r\n','img_2012201223432.jpg','7.50','','Wraps'),
	(61,'GREAT CHICKEN SANDWICH','Great Chicken salad mix on your choice of bread, you can\'t go wrong with\r\n','img_2012205211312.jpg','6.95','','Sandwiches'),
	(62,'Santa Fe Wrap','\r\nGrilled chicken, roasted corn, black beans, sliced pepper jack cheese, shredded mozzarella cheese, green leaf lettuce, cucumber, tomato; served with Southwestern sauce on the side, and your choice of tortilla flavor (recommended: on sundried tomato tortilla)\r\n\r\n','img_2012261123636.jpg','6.95','','Wraps'),
	(81,'Fancy Tray','Grilled chicken stripes, unsalted almonds, green apples, young cucumber, edamame, cherry tomatoes, baby brie cheese, grapes, strawberries and whole grain crackers; your choice of dipping sauce or dressing to be served on side\r\n','img_20122611215632.jpg','7.89','new','Salads'),
	(82,'Super-Taco Salad Meal','Chicken cubes; roasted corn, black beans, cherry tomatoes, with both pepper jack, and grated mixed cheese, topped with sour cream, avocado and jalapenos; served with pico de gallo, chips and salsa; Recommended with southwestern dressing (Santa Fe)\r\n','img_20122611215828.jpg','8.99','','Salads'),
	(83,'Beef Taco Salad','Seasoned ground Beef, iceberg lettuce, Cheddar & Monterey cheese, pico de gallo, jalapenos, tortilla chips; served with extra corn chips and salsa on the side; recommended with Taco seasoned dressing \r\n','img_2012261122057.jpg','8.79','','Salads'),
	(84,'Fresh Mex w/Steak','\r\nSeasoned steak strips; roasted corn, onion, avocado, tomatoes, black beans, bell pepper, gelso cheese, topped with fresh avocado and jalapeno; served with pico de gallo, chips and salsa on the side; Recommended with southwestern dressing \r\n','img_2012261122145.jpg','9.95','','Salads'),
	(85,'Healthy Mex w/Pollo','Grilled Chicken breast, black beans, roasted corn, roasted bell pepper, avocado, jicama, tomato, and cilantro; served with pico de gallo, corn chips and salsa on side; Recommended with honey-lime vinaigrette dressing\r\n','img_2012261122252.jpg','8.79','','Salads'),
	(86,'Chef’s Meal Salad ','	\r\nOven-roasted Turkey, or Chicken Breast; ham, bacon crumbles, cucumber, tomato, cheddar & Monterey cheese, hard boiled eggs, olives, parsley; served with multigrain roll and butter chip on the side; Recommended with Ranch dressing \r\n','img_2012261122334.jpg','7.99','','Salads'),
	(87,'Chicken-salad on Green','\r\nTender all white breasts of chicken, crisp celery, apple, cashew nuts, and juicy raisins, and cherry tomatoes, on a seasoned dressing on fresh mixed green lettuce; served with fruit cup and crackers on the side\r\n','img_2012261122422.jpg','7.99','','Salads'),
	(88,'Caesar Salad (Salmon or Chicken)','You choice of Salmon fillet or Chicken breast, on freshly cut crispy Romaine lettuce, croutons, and shaved parmesan cheese, served with Garlic bread and butter chips on the side; you can choose creamy or regular Caesar dressing from dressing choices option\r\n','img_2012261122550.jpg','7.99','','Salads'),
	(89,'Avocado Chicken Salad','\r\nGrilled Chicken breast, avocado, bacon, cucumber, cherry tomatoes, served with crunchy bread and butter; recommended on a bed of romaine lettuce and Ranch dressing\r\n','img_2012261122647.jpg','8.75','','Salads'),
	(90,'Chopped Greek w/Artichoke',' \r\nGrilled Chicken breast (seasoned Souvlaki style, salt, pepper, and olive oil only); sliced fresh cucumber, tomatoes, olives, artichoke hearts, Italian parsley, Feta cheese, lemon juice, black pepper, extra virgin olive oil; recommended over a bedding of Organic green mix\r\n','img_2012261122813.jpg','8.99','','Salads'),
	(91,'Oven-baked Turkey Cobb','\r\nBoard carved oven-baked Turkey breast, avocado, cucumber, Swiss cheese, hardboiled egg, dried cranberries, cherry tomatoes; served with crunchy herb-bread and butter chips on the side; Recommended with Ranch dressing\r\n','img_201226112293.jpg','7.99','','Salads'),
	(92,'California Cobb','Grilled Chicken breast; fresh corn, tomato, hard broiled eggs, bacon, avocado, blue cheese, over Organic baby greens and iceberg lettuce mix; served with artisan ciabatta roll and butter chips on the side; Recommended with Balsamic or Raspberry vinaigrette dressing\r\n','img_2012261122105.jpg','8.99','','Salads'),
	(93,'Tuna Pasta Salad Meal','Albacore tuna chunks over lightly seasoned penne pasta, cherry tomato, parsley, sweet green peas, served with organic baby spinach leafs, feta cheese, and crunchy multigrain on the side \r\n','img_20122611221055.jpg','7.89','','Salads'),
	(94,'Chinese Chicken Salad','Grilled Chicken breast, Fresh iceberg lettuce, Napa cabbage, mandarin orange hearts, water chestnuts, red cabbage, green peas, carrot, green onion, cilantro, rice noodle; served with Oriental sesame ginger dressing on the side\r\n','img_2012221491259.jpg','8.25','','Salads'),
	(95,'Edamame & Cabbage Salad Meal','Shredded Chicken, iceberg lettuce, Napa cabbage, red cabbage, green peas, shredded carrot, chopped green onion, cilantro, rice noodle; Recommended with Oriental sesame ginger\r\n','img_20122611221423.jpg','7.99','','Salads'),
	(96,'Thai Grilled Chicken Salad Meal','Thai Spicy Grilled Chicken, wild rice side, shredded carrots, red cabbage, bean sprouts, tomato, wonton strips, hint of chopped green onion, cilantro, lime veggie , peanuts and cashews; served with Sesame-ginger soy sauce and Thai style peanut-sauce on the side; your choice of lettuce \r\n','img_20122611221515.jpg','8.79','','Salads'),
	(97,'Cajun Salmon or Chicken Salad ','Blackened Salmon or Chicken fillet over Organic spring mix bedding, sprouts, dried cranberries, hint of green onion, cherry tomatoes, walnuts, feta cheese, red onion; Recommended with sweet vinaigrette dressing\r\n','img_20122611221614.jpg','8.99','','Salads'),
	(98,'Cranberry, Pecan & Pears','Grilled Chicken breast, or Salmon Fillet; cucumber, cherry tomato, cranberries, carmelized pecans, feta cheese, pear, parsley, sprouts, and mozzarella cheese, over baby spinach or your choice of lettuce; Recommended with Vanilla white bean vinaigrette dressing\r\n','img_20122611221717.jpg','8.75','','Salads'),
	(99,'Antioxidant (B.Hills)','Your choice of Salmon fillet or Chicken Breast; dried cranberries, strawberries, fresh blueberries, green apple, fresh mint leafs, hint of red onion, cherry tomato, cucumbers, goat cheese; Recommended with vanilla-bean balsamic vinaigrette dressing, and baby spinach or spring mix\r\n','img_20122611221822.jpg','8.99','','Salads'),
	(100,'Organic Spinach Salad Meal','Grilled Chicken breast; Sliced strawberries, mandarin orange hearts, avocado, pine nuts, goat cheese, all on fresh spinach bedding; Recommended with Balsamic vinaigrette dressing\r\n','img_20122611221931.jpg','8.79','','Salads'),
	(101,'Fresh Fruit Salad','\r\nFresh seasonal fruit: strawberries, green apple, oranges, pineapple, grapes, and blueberries, served with our signature Caramelized fruit dipping sauce\r\n','img_20122611222621.jpg','5.39','','REGULAR SALADS & Side Orders'),
	(102,'Veggies with Ranch','\r\nOrganic baby carrot, cucumber, celery, broccoli, hardboiled egg, fancy cheese, and your choice of Ranch or Humus dip \r\n','img_20122611222656.jpg','5.79','','REGULAR SALADS & Side Orders'),
	(103,'Tofu Pasta Salad (Vegetarian)','Pasta rotini lightly seasoned, with cubes of tofu marinated in sesame ginger dressing, green peas, and sesame seeds; perfect office meal, refreshing and easy ','img_20122611222810.jpg','5.95','','REGULAR SALADS & Side Orders'),
	(104,'Caprese Salad (Vegetarian)','Fine cut steak tomato on a bed of organic Green Mix, Fresh Mozzarella cheese, fresh basil leaves, green olives, tossed in light olive oil; Recommended with balsamic vinaigrette only\r\n','img_20122611222850.jpg','5.95','','REGULAR SALADS & Side Orders'),
	(105,'Quinoa Salad (Vegetarian)','Cooked quinoa, lightly steamed veg, cherry tomato, carrots, cucumber, edamame beans, fresh herbs, toasted pine nuts or seeds, olive oil & lemon, recommended over baby spinach, or your choice of lettuce\r\n','img_20122611222935.jpg','5.99','','REGULAR SALADS & Side Orders'),
	(106,'Organic Green Salad','Organic baby spring mix, cherry tomatoes, sliced young cucumbers, avocado, shaved parmesan cheese, and hint of green onion, tossed with salt and pepper, olive oil, and white balsamic vinaigrette, or your choice of dressing\r\n(add Chicken for $1.25, in customization drop down menu)\r\n','img_201221131947.jpg','5.99','','REGULAR SALADS & Side Orders'),
	(107,'Albacore Tuna Salad on Green','\r\nDescription: Albacore tuna mixed with celery, white pepper, green olives, pickles, mayo, served with cherry tomatoes, cucumbers and multigrain crackers, over organic spinach or spring mix; recommended dressing: Raspberry vinaigrette','img_20122611224340.jpg','6.95','','REGULAR SALADS & Side Orders'),
	(108,'Organic Spinach Cobb ','\r\nGrilled chicken, hard broiled eggs, cucumber, cherry tomatoes, avocado, and hint of red onions, originally served on a bed of Organic baby spinach, topped with thin sliced Swiss cheese and crumbled bacon; Recommended with honey mustard dressing; you can change your lettuce choice as well\r\n','img_2012261122344.jpg','6.95','','REGULAR SALADS & Side Orders'),
	(109,'Orange-Coated Almonds','\r\nGrilled Chicken breast, slices of sweet and juicy oranges, alfalfa sprouts, cherry tomato, shaved parmesan cheese, and orange coated almonds; Recommended with vanilla bean balsamic vinaigrette dressing, and Organic spring mix (or you choice of lettuce)\r\n','img_20122611223525.jpg','6.99','','REGULAR SALADS & Side Orders'),
	(110,'Candy Walnut & Apples','\r\nGrilled Chicken stripes, candied walnuts, green apples, cherry tomatoes, blue cheese; recommended dressing Balsamic-vinaigrette, on your choice of lettuce\r\n','img_20122611223611.jpg','6.95','','REGULAR SALADS & Side Orders'),
	(111,'Chicken Caesar Wrap','Grilled chicken, romaine lettuce, hint of red onion, parmesan cheese, bacon, crunched croutons; served with creamy Caesar dipping sauce on the side\r\n','img_2012201223117.jpg','6.95','','Wraps'),
	(112,'Thai Grilled-Chicken Wrap','Thai grilled chicken breasts, green leaf lettuce, tomato, cucumber, shredded carrot, bean sprouts, cilantro, served with Thai-peanut dipping sauce and sesame-ginger on the side\r\n','img_20122012231346.jpg','7.25','','Wraps'),
	(114,'Chicken-salad Wrapped','Our delicious chicken salad mix, green leafs, sprouts, and orange hearts, wrapped tortilla of your choice (whole wheat, spinach-herb, sundried-tomato, pesto-garlic, and other flavors available)\r\n','img_20122012231725.jpg','6.95','','Wraps'),
	(115,'Turkey-Avocado ','Sliced turkey breast, cucumber, avocado, tomato, green leaf lettuce, herbs & cream cheese spread, provolone cheese, wrapped in variety of tortilla flavors offered (by your choice), and served with cranberry ranch dipping sauce on the side\r\n','img_20122012231953.jpg','7.25','','Wraps'),
	(116,'Avocado Veggie Wrap','Avocado, green leaf lettuce, cucumber, tomato, sliced bell pepper, shredded carrots, alfalfa sprouts, cilantro, olive oil drizzled; recommended in spinach or sundried tomato wrap, your choice of Ranch, humus, or other sauces on the side\r\n','img_20122012232058.jpg','6.95','','Wraps'),
	(117,'Ceral & milk','Choose your favorite breakfast cerals from drop-down menu. We will send it with Horizon Organic low fat regular or chocolate Milk','img_2012232913449.jpg','2.89','','Breakfast');

/*!40000 ALTER TABLE `lunchbox` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lunchBoxCat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lunchBoxCat`;

CREATE TABLE `lunchBoxCat` (
  `idlunchBoxCat` int(30) NOT NULL AUTO_INCREMENT,
  `lunchBoxCatName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxCatDesc` text COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxCatImg` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxCatType` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idlunchBoxCat`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `lunchBoxCat` WRITE;
/*!40000 ALTER TABLE `lunchBoxCat` DISABLE KEYS */;
INSERT INTO `lunchBoxCat` (`idlunchBoxCat`,`lunchBoxCatName`,`lunchBoxCatDesc`,`lunchBoxCatImg`,`lunchBoxCatType`)
VALUES
	(1,'DESSERT',' \r\n','img_20121325235917.jpg','Desserts'),
	(2,'HEALTHY SNACKS ','','img_2012142602235.jpg','Desserts'),
	(8,'SMALL & SIDE ORDERS','','img_2012142603435.jpg','Apetizers & Sides'),
	(9,'SOFT DRINKS','','img_201214260159.jpg','Beverages & other'),
	(3,'BOTTLED WATER','','img_20122329133216.jpg','Beverages & other'),
	(4,'VITAMIN WATER','','img_2012132519150.jpg','Beverages & other'),
	(5,'MINERAL WATER','','img_20121426184524.jpg','Beverages & other'),
	(6,'GATORADE','','img_2012132519748.jpg','Beverages & other'),
	(7,'SODAS','','img_2012142601554.jpg','Beverages & other'),
	(10,'WHOLE FRESH FRUIT ','','img_2012142602712.jpg','Desserts'),
	(11,'CHIPS & SNACKS','','img_2012152701118.jpg','Beverages & other'),
	(12,'ENERGY DRINKS','','img_20121527172656.jpg','Beverages & other');

/*!40000 ALTER TABLE `lunchBoxCat` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lunchBoxItem
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lunchBoxItem`;

CREATE TABLE `lunchBoxItem` (
  `idlunchBoxItem` int(11) NOT NULL AUTO_INCREMENT,
  `lunchBoxItemName` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxItemDesc` text COLLATE utf8_unicode_ci NOT NULL,
  `idlunchBoxCat` int(30) NOT NULL,
  `lunchBoxItemStatus` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `lunchBoxItemPrice` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idlunchBoxItem`)
) ENGINE=MyISAM AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `lunchBoxItem` WRITE;
/*!40000 ALTER TABLE `lunchBoxItem` DISABLE KEYS */;
INSERT INTO `lunchBoxItem` (`idlunchBoxItem`,`lunchBoxItemName`,`lunchBoxItemDesc`,`idlunchBoxCat`,`lunchBoxItemStatus`,`lunchBoxItemPrice`)
VALUES
	(13,'Perrier (11.15 fl oz)','',5,'','2.29'),
	(2,'Kelloggs Nutrigrain Bar','',2,'','1.50'),
	(38,'Quaker Oatmeal Chewy Bar','',2,'','1.50'),
	(6,'Chocolate chip Cookies','',1,'','1.25'),
	(7,'Oatmeal Cookie','',1,'','1.25'),
	(8,'Carrot Cake','',1,'','3.50'),
	(9,'Arrowhead (16.9 fl oz)','',3,'','0.95'),
	(10,'Chrystal Gyezer (16.9 fl oz)','',3,'','0.95'),
	(11,'Endurance - Regular (20oz)','',4,'','1.79'),
	(12,'Endurance - Zero (20 oz)','',4,'','1.89'),
	(14,'San Pellegrino (11.15 fl oz)','',5,'','2.29'),
	(15,'Lemon-Lime (20oz)','',6,'','1.89'),
	(16,'Orange (20oz)','',6,'','1.89'),
	(17,'Fruit Punch (20oz)','',6,'','1.89'),
	(19,'COKE (12oz)','',7,'','0.99'),
	(66,'DIET Coke (12 oz)','',7,'','0.99'),
	(67,'COKE - Zero (12oz)','',7,'','1.10'),
	(24,'Lemon Bar','',1,'','2.95'),
	(25,'Famous Brownie','',1,'','2.49'),
	(26,'Cheese Cake w/fruit trimming ','',1,'','3.89'),
	(27,'Fuji Apple','',10,'','1.35'),
	(28,'Green Apple - Organic','',10,'','1.15'),
	(30,'Banana - Organic','',10,'','1.25'),
	(32,'Orange ','',10,'','0.99'),
	(33,'Fresh Strawberries (8oz)','',10,'','3.79'),
	(34,'Fresh Blueberries (3.5oz)','',10,'','1.99'),
	(35,'Pineapple (8oz)','',10,'','2.95'),
	(36,'Honeydew (8oz)','',10,'','2.89'),
	(37,'Fiber Plus Antioxidant Bar','',2,'','1.50'),
	(39,'Nature Valley Protein Bar','Peanut Butter Dark Chocolate',2,'','1.25'),
	(40,'Nature Valley Protein BarPeanut Butter Dark Chocolate','',2,'','1.25'),
	(41,'Fiber One Flax Plus Pumpkin Granola Bar','',2,'','1.25'),
	(42,'Cantaloupe (8oz)','',10,'','2.89'),
	(127,'Grape Medley (12oz)','',10,'','3.49'),
	(44,'O.J. - Freshly squeezed (12oz)','',9,'','3.49'),
	(45,'Tropicana Orange Juice (10oz)','',9,'','1.89'),
	(47,'Cranberry Juice (10oz)','',9,'','1.99'),
	(50,'San Pellegrino - Lime (11.15 oz)','',5,'','2.25'),
	(51,'Highland Springs (16.5 fl oz)','',5,'','2.29'),
	(52,'Milk - Organic (Horizon)','',9,'','2.00'),
	(53,'Chocolate Milk - Organic','',9,'','2.25'),
	(55,'Aquafina (16.9 fl oz)','',3,'','1.00'),
	(56,'Smart Water','',3,'','1.49'),
	(57,'FIJI','',3,'','1.49'),
	(58,'Strength - Regular (20oz)','',4,'','1.79'),
	(59,'Strength - Zero (20oz)','',4,'','1.89'),
	(60,'Essential - Regular (20oz)','',4,'','1.79'),
	(61,'Essential - Zero (20oz)','',4,'','1.89'),
	(62,'Focus - Regular (20oz)','',4,'','1.79'),
	(63,'Focus - Zero (20oz)','',4,'','1.89'),
	(64,'Balance - Regular (20oz)','',4,'','1.79'),
	(65,'Balance - Zero (20oz)','',4,'','1.89'),
	(68,'PEPSI (12 oz)','',7,'','0.99'),
	(69,'DIET Pepsi (12oz)','',7,'','0.99'),
	(72,'Dr. Pepper - Regular (12oz)','',7,'','0.99'),
	(73,'Dr. Pepper - Diet (12oz)','',7,'','0.99'),
	(74,'Dr. Pepper - Cherry (12oz)','',7,'','0.99'),
	(75,'Sprite - Regular (12oz)','',7,'','0.99'),
	(76,'Sprite - Diet (12oz)','',7,'','0.99'),
	(77,'7-UP - Regular (12oz)','',7,'','0.99'),
	(78,'7-UP - Diet (12oz)','',7,'','0.99'),
	(79,'Mountain Dew (12oz)','',7,'','0.99'),
	(80,'Mountain Dew - Diet (12oz)','',7,'','0.99'),
	(82,'FANTA - Orange (12oz)','',7,'','0.99'),
	(84,'Edamame (8oz)','',8,'','2.95'),
	(85,'Rice - regular (8oz)','',8,'','1.50'),
	(86,'Brown Rice (8oz)','',8,'','1.95'),
	(87,'Orzo Pasta Salad (8oz)','',8,'','2.99'),
	(89,'Caprese Pasta Salad (8oz)','',8,'','2.50'),
	(90,'Rotini Pasta Salad (8oz)','',8,'','2.89'),
	(91,'Tuna-Chipotle Pasta Salad (8oz)','',8,'','2.99'),
	(94,'Beet Salad (8oz)','',8,'','2.95'),
	(95,'Potato Salad (8oz)','',8,'','2.95'),
	(96,'Coleslaw (6oz)','',8,'','2.25'),
	(97,'Small Caesar Salad (16oz)','',8,'','3.25'),
	(98,'Small Green Salad (16oz)','',8,'','3.25'),
	(99,'Chips & Salsa (16 oz)','',8,'','3.79'),
	(100,'LAYS Potato Chips - Original (1oz)','',11,'','0.99'),
	(101,'LAYS Potato Chips - BBQ (1oz)','',11,'','0.99'),
	(102,'KETTLE CLASSICS - Natural (1.75oz)','',11,'','1.29'),
	(103,'KETTLE CLASSICS - Salt & Pepper (1.75oz)','',11,'','1.29'),
	(104,'KETTLE CLASSICS - Salt & Vinegar (1.75oz)','',11,'','1.29'),
	(106,'KETTLE CLASSICS - BBQ (1.75oz)','',11,'','1.29'),
	(107,'SUN CHIPS - Original (1.5oz)','',11,'','1.29'),
	(108,'SUN CHIPS - French onion (1.5oz)','',11,'','1.29'),
	(109,'SUN CHIPS - Garden Salsa (1.5oz)','',11,'','1.29'),
	(110,'SUN CHIPS - Cheddar (1.5oz)','',11,'','1.29'),
	(111,'CHITOS - Crunchy (1.5 oz)','',11,'','1.39'),
	(112,'CHITOS - Puffs (1.5oz)','',11,'','1.49'),
	(113,'DORITOS - Ranch (1oz)','',11,'','0.99'),
	(114,'DORITOS - Nacho Cheese (1oz)','',11,'','0.99'),
	(115,'DORITOS - Collisions ','',11,'','1.50'),
	(116,'RAW ALMONDS (3.5oz)','',11,'','2.19'),
	(118,'PLANTERS PEANUTS - Salted (1oz)','',11,'','1.79'),
	(119,'PLANTERS MIXED NUTS (1oz)','',11,'','1.89'),
	(120,'SNICKERS Bar','',11,'','1.69'),
	(121,'TWIX','',11,'','1.79'),
	(122,'BOUNTY Coconut','',11,'','1.49'),
	(123,'Red Bull - Sugar Free (8.4oz)','',12,'','2.95'),
	(124,'Red Bull - Regular (8.4oz)','',12,'','2.89'),
	(125,'Rock Star (16oz)','',12,'','3.29'),
	(126,'Rock Star - Diet (16oz)','',12,'','3.29'),
	(128,'Red Velvet Cheese Cake','',1,'','3.89'),
	(129,'Monster - Reg. (16 oz)','',12,'','2.29'),
	(130,'Monster - Sugar Free (16 oz)','',12,'','2.29');

/*!40000 ALTER TABLE `lunchBoxItem` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table order_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `order_content`;

CREATE TABLE `order_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `item_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_price` decimal(11,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `lunch_box_id` int(11) DEFAULT NULL,
  `lunch_box_item_id` int(11) DEFAULT NULL,
  `drop_down_item_id` int(11) DEFAULT NULL,
  `parent_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subtotal` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `order_content` WRITE;
/*!40000 ALTER TABLE `order_content` DISABLE KEYS */;
INSERT INTO `order_content` (`id`,`order_id`,`item_id`,`item_name`,`item_price`,`quantity`,`lunch_box_id`,`lunch_box_item_id`,`drop_down_item_id`,`parent_id`,`type`,`subtotal`)
VALUES
	(1,1,'lunch-box-menu-item-100-2','Organic Spinach Salad Meal',8.79,1,100,0,0,'-1','meal',16.21),
	(2,1,'15','Balsamic Vinaigrette',0.00,1,0,0,15,'lunch-box-menu-item-100-2','addon',0.00),
	(3,1,'142','Chicken Breast',0.00,1,0,0,142,'lunch-box-menu-item-100-2','addon',0.00),
	(4,1,'custom-kitchen-messsage-100','Custom Kitchen Message:no onions',1.50,1,0,0,0,'lunch-box-menu-item-100-2','addon',0.00),
	(5,1,'110','Fiji Apple - Organic',1.39,1,0,0,110,'lunch-box-menu-item-100-2','addon',0.00),
	(6,1,'11','Chocolate Chip Cookie',1.25,1,0,0,11,'lunch-box-menu-item-100-2','addon',0.00),
	(7,1,'126','Smart Water',1.79,1,0,0,126,'lunch-box-menu-item-100-2','addon',0.00),
	(8,1,'7','Kettle One - Natural',1.49,1,0,0,7,'lunch-box-menu-item-100-2','addon',0.00),
	(9,1,'lunch-box-menu-item-99-3','Antioxidant (B.Hills)',8.99,1,99,0,0,'-1','meal',8.99),
	(10,1,'lunch-box-menu-item-6-4','Chocolate chip Cookies',1.25,3,0,6,0,'-1','meal',3.75),
	(11,1,'lunch-box-menu-item-44-5','O.J. - Freshly squeezed (12oz)',3.49,3,0,44,0,'-1','meal',10.47),
	(12,2,'lunch-box-menu-item-100-2','Organic Spinach Salad Meal',8.79,1,100,0,0,'-1','meal',16.21),
	(13,2,'15','Balsamic Vinaigrette',0.00,1,0,0,15,'lunch-box-menu-item-100-2','addon',0.00),
	(14,2,'142','Chicken Breast',0.00,1,0,0,142,'lunch-box-menu-item-100-2','addon',0.00),
	(15,2,'custom-kitchen-messsage-100','Custom Kitchen Message:no onions',1.50,1,0,0,0,'lunch-box-menu-item-100-2','addon',0.00),
	(16,2,'110','Fiji Apple - Organic',1.39,1,0,0,110,'lunch-box-menu-item-100-2','addon',0.00),
	(17,2,'11','Chocolate Chip Cookie',1.25,1,0,0,11,'lunch-box-menu-item-100-2','addon',0.00),
	(18,2,'126','Smart Water',1.79,1,0,0,126,'lunch-box-menu-item-100-2','addon',0.00),
	(19,2,'7','Kettle One - Natural',1.49,1,0,0,7,'lunch-box-menu-item-100-2','addon',0.00),
	(20,2,'lunch-box-menu-item-99-3','Antioxidant (B.Hills)',8.99,1,99,0,0,'-1','meal',8.99),
	(21,2,'lunch-box-menu-item-6-4','Chocolate chip Cookies',1.25,3,0,6,0,'-1','meal',3.75),
	(22,2,'lunch-box-menu-item-44-5','O.J. - Freshly squeezed (12oz)',3.49,3,0,44,0,'-1','meal',10.47),
	(23,3,'lunch-box-menu-item-100-2','Organic Spinach Salad Meal',8.79,1,100,0,0,'-1','meal',16.21),
	(24,3,'15','Balsamic Vinaigrette',0.00,1,0,0,15,'lunch-box-menu-item-100-2','addon',0.00),
	(25,3,'142','Chicken Breast',0.00,1,0,0,142,'lunch-box-menu-item-100-2','addon',0.00),
	(26,3,'custom-kitchen-messsage-100','Custom Kitchen Message:no onions',1.50,1,0,0,0,'lunch-box-menu-item-100-2','addon',0.00),
	(27,3,'110','Fiji Apple - Organic',1.39,1,0,0,110,'lunch-box-menu-item-100-2','addon',0.00),
	(28,3,'11','Chocolate Chip Cookie',1.25,1,0,0,11,'lunch-box-menu-item-100-2','addon',0.00),
	(29,3,'126','Smart Water',1.79,1,0,0,126,'lunch-box-menu-item-100-2','addon',0.00),
	(30,3,'7','Kettle One - Natural',1.49,1,0,0,7,'lunch-box-menu-item-100-2','addon',0.00),
	(31,3,'lunch-box-menu-item-99-3','Antioxidant (B.Hills)',8.99,1,99,0,0,'-1','meal',8.99),
	(32,3,'lunch-box-menu-item-6-4','Chocolate chip Cookies',1.25,3,0,6,0,'-1','meal',3.75),
	(33,3,'lunch-box-menu-item-44-5','O.J. - Freshly squeezed (12oz)',3.49,3,0,44,0,'-1','meal',10.47),
	(34,3,'lunch-box-menu-item-100-6','Organic Spinach Salad Meal',8.79,1,100,0,0,'-1','meal',8.79),
	(35,3,'lunch-box-menu-item-100-7','Organic Spinach Salad Meal',8.79,1,100,0,0,'-1','meal',8.79),
	(36,3,'lunch-box-menu-item-100-8','Organic Spinach Salad Meal',8.79,1,100,0,0,'-1','meal',8.79),
	(37,3,'lunch-box-menu-item-100-9','Organic Spinach Salad Meal',8.79,1,100,0,0,'-1','meal',8.79),
	(38,3,'lunch-box-menu-item-100-10','Organic Spinach Salad Meal',8.79,1,100,0,0,'-1','meal',8.79),
	(39,3,'lunch-box-menu-item-96-11','Thai Grilled Chicken Salad Meal',8.79,1,96,0,0,'-1','meal',8.79),
	(40,3,'lunch-box-menu-item-93-12','Tuna Pasta Salad Meal',7.89,1,93,0,0,'-1','meal',7.89),
	(41,3,'lunch-box-menu-item-96-13','Thai Grilled Chicken Salad Meal',8.79,1,96,0,0,'-1','meal',13.93),
	(42,3,'49','Ranch',0.00,1,0,0,49,'lunch-box-menu-item-96-13','addon',0.00),
	(43,3,'4','Romaine lettuce',0.00,1,0,0,4,'lunch-box-menu-item-96-13','addon',0.00),
	(44,3,'109','Green Apple -Organic',1.25,1,0,0,109,'lunch-box-menu-item-96-13','addon',0.00),
	(45,3,'11','Chocolate Chip Cookie',1.25,1,0,0,11,'lunch-box-menu-item-96-13','addon',0.00),
	(46,3,'12','Coca cola - Regular',1.15,1,0,0,12,'lunch-box-menu-item-96-13','addon',0.00),
	(47,3,'7','Kettle One - Natural',1.49,1,0,0,7,'lunch-box-menu-item-96-13','addon',0.00),
	(48,3,'lunch-box-menu-item-81-14','Fancy Tray',7.89,1,81,0,0,'-1','meal',7.89),
	(49,3,'lunch-box-menu-item-82-15','Super-Taco Salad Meal',8.99,1,82,0,0,'-1','meal',8.99),
	(50,3,'lunch-box-menu-item-110-16','Candy Walnut &#38; Apples',6.95,1,110,0,0,'-1','meal',6.95);

/*!40000 ALTER TABLE `order_content` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table orders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `id` int(240) NOT NULL AUTO_INCREMENT,
  `order_type_id` int(1) NOT NULL,
  `company_id` int(11) NOT NULL,
  `customer_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `customer_email` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `time` time NOT NULL,
  `date` date NOT NULL,
  `message` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `payed` tinyint(4) DEFAULT NULL,
  `order_total` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`,`order_type_id`,`company_id`,`customer_name`,`customer_email`,`time`,`date`,`message`,`payed`,`order_total`)
VALUES
	(1,0,5,'Tomislav Palic','tom.palic.programming@gmail.com','09:20:00','2012-03-22','',1,NULL),
	(2,0,5,'Tomislav Palic','tom.palic.programming@gmail.com','09:20:00','2012-03-22','',1,NULL),
	(3,0,5,'Tomislav Palic','tom.palic.programming@gmail.com','09:20:00','2012-03-22','',1,NULL);

/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table pages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `pages`;

CREATE TABLE `pages` (
  `idPage` int(30) NOT NULL AUTO_INCREMENT,
  `permalinkPage` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `pageContent` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idPage`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` (`idPage`,`permalinkPage`,`pageContent`)
VALUES
	(1,'lunch-box-menu',''),
	(2,'why-ccol','<h2 style=\"text-transform: none; text-align: center; \">\r\n	<span style=\"font-size:22px;\"><span style=\"color: rgb(255, 165, 0); \">PRACTICE HEALTHY DIET &amp; LIFE STYLE AT YOUR WORKPLACE&nbsp;</span></span></h2>\r\n<p style=\"text-transform: none; text-align: left; \">\r\n	<span style=\"font-size: 14px; \"><span style=\"color:#ffa500;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>CORPORATE CATERING ONLINE</strong></span></span><span style=\"font-family: verdana, geneva, sans-serif; \"><span style=\"color:#ffa500;\"> </span>is a unique, completely NEW business model, that had never been offered before.</span><font face=\"tahoma, geneva, sans-serif\"><b>&nbsp;</b></font></span><span style=\"font-family:verdana,geneva,sans-serif;\"><span style=\"font-size: 14px; \">We provide healthy alternative to all busy working men and women who struggle to practice appropriate diet, and enjoy freshly made, nutritionally rich, and quality daily meal at their busy work place. Or simpler, we offer healthy alternative to eating out every day. We are not middleman between you and the restaurants, so you don&#39;t need to pay for expensive delivery, or service fees. We offer</span></span><span style=\"font-family: verdana, geneva, sans-serif; font-size: 14px; \">&nbsp;FREE DELIVERY and NO MINIMUM ORDER is required.&nbsp;</span><span style=\"font-size: 14px; font-family: verdana, geneva, sans-serif; \">Our Menu is carefully crafted for those who would want and expect more nutrition, better value, and freshest ingredients, than what has been offered in fast-food restaurants, downstairs Cafes, and especially Vending machines, or unreliable vendor trucks and coolers. We offer tasty, delicious, vibrant, and freshly made meal selection that will help you perform better and go through your day right. Plus enjoy your favorite dish exactly the way you want it. Fully customize your order, and add variety of snacks, drinks, or even whole fresh fruit.&nbsp;</span></p>\r\n<div id=\"lipsum\">\r\n	<p>\r\n		<span style=\"font-size:14px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><span style=\"color:#ffa500;\"><strong>OUR MISSION</strong></span> is to provide&nbsp;</span></span><span style=\"font-family: verdana, geneva, sans-serif; font-size: 14px; \">freshly made, nutritionally rich and healthy meals, and convenience of FREE DELIVERY,</span><span style=\"font-family: verdana, geneva, sans-serif; font-size: 14px; \">&nbsp;to all busy people who struggle to practice healthy diet and healthy life style at their work place.</span></p>\r\n	<p>\r\n		<span style=\"color:#ffa500;\"><font face=\"tahoma, geneva, sans-serif\" style=\"font-size: 16px; \"><strong><img alt=\"\" src=\"http://www.corporatecateringonline.com/images/upload/img_201222721141.jpg\" style=\"float: right; width: 315px; height: 458px; \" />EAT HEALTHY &amp; FRESH -&nbsp;</strong></font><span style=\"font-size: 16px; \"><font face=\"tahoma, geneva, sans-serif\"><strong>even if you are busy or overwhelmed with work&nbsp;</strong></font></span></span></p>\r\n	<p>\r\n		<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- WE PREPARE OUR MEALS FROM ORGANIC, ALL NATURAL, AND NEVER FROZEN INGREDIENTS</span></p>\r\n	<p>\r\n		<span style=\"font-size: 14px; font-family: tahoma, geneva, sans-serif; \">- OUR CAREFULLY SELECTED MENU LET YOU CHOOSE FROM VARIETY OF HEALTHY AND VIBRANT OPTIONS</span></p>\r\n	<p>\r\n		<span style=\"font-size: 14px; font-family: tahoma, geneva, sans-serif; \">- YOU CAN FULLY CUSTOMIZE YOUR ORDER </span></p>\r\n	<p>\r\n		<span style=\"font-size: 14px; font-family: tahoma, geneva, sans-serif; \">- ALL MEALS ARE PREPARED EXACTLY THE WAY YOU ORDERED, AND YOU ARE RECEIVING IT LABELED, WITH YOUR NAME ON IT</span></p>\r\n	<p>\r\n		<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- WE ALSO OFFER GREAT AND HEALTHY BREAKFAST CHOICES, AND YOU CAN ENJOY THEM AT YOUR PREFERRED DELIVERY TIME</span></p>\r\n	<p>\r\n		<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- BESIDE THAT, YOU WON&#39;T NEED TO WORRY ANYMORE WHERE, WHEN, AND HOW TO GET YOUR LUNCH EVERY DAY. SAVE YOURSELF FROM ALL THAT HASSLE. WE DELIVER FOR FREE AND ALWAYS ON TIME&nbsp;</span></p>\r\n	<p>\r\n		<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- WE OFFER MORE THEN JUST BREAKFAST, SANDWICHES AND SALADS, WE ALSO CARRY SOME CONVENIENCE-STORE ITEMS, INCLUDING WHOLE FRESH FRUITS, GREAT SELECTION OF BEVERAGES, AND HEALTHY SNACKS</span></p>\r\n	<p>\r\n		<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">-&nbsp;</span><span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">YOU DON&#39;T NEED TO RUSH OUT FOR LUNCH-BREAK ANY MORE...</span><span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">YOUR LUNCH IS NOW DELIVERED TO YOU&nbsp;<strong>FOR FREE</strong>&nbsp;AND&nbsp;WITH&nbsp;CORPORATE CATERING ONLINE</span><span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">&nbsp;YOU CAN PLAN YOUR DAY RIGHT AND</span><span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">&nbsp;<strong>ENJOY YOUR WELL DESERVED LUNCH BREAK</strong></span></p>\r\n	<p>\r\n		<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- SATISFACTION GUARANTEED OR YOUR MONEY BACK</span></p>\r\n	<p style=\"text-align: left; \">\r\n		<span style=\"color:#696969;\"><span style=\"font-size:18px;\"><span style=\"text-align: left; \">CORPORATE CATERING ONLINE IS THE BEST WAY TO PLAN YOUR DAY!</span></span></span></p>\r\n</div>\r\n<p>\r\n	<span style=\"color:#ffd700;\"><font face=\"tahoma, geneva, sans-serif\" style=\"font-size: 16px; \">&nbsp;</font></span><span style=\"color:#ffa500;\"><strong style=\"font-size: 16px; font-family: arial, helvetica, sans-serif; \">SAVE TIME, SAVE $$$, ENJOY CONVENIENCE OF&nbsp;FREE DELIVERY&nbsp;</strong></span></p>\r\n<p>\r\n	<span style=\"font-size: 14px; \"><span style=\"font-family: tahoma, geneva, sans-serif; \"><img alt=\"\" src=\"http://www.corporatecateringonline.com/images/upload/img_2012216123336.jpg\" style=\"float: right; width: 315px; height: 210px; \" />- OUR DELIVERY IS ABSOLUTELY FREE, NO HIDDEN FEES, NO GIMMICKS</span></span></p>\r\n<p>\r\n	<span style=\"font-size: 14px; \"><span style=\"font-family: tahoma, geneva, sans-serif; \">- NO MINIMUM ORDER REQUIREMENTS</span></span></p>\r\n<p>\r\n	<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- MORE THEN AFFORDABLE PRICES, BEST VALUE FOR THE DOLLAR</span></p>\r\n<p>\r\n	<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- PLUS RECEIVE DISCOUNTS, COUPONS, AND SPECIALS</span></p>\r\n<p>\r\n	<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- ALL AT ONE PLACE, SINGLE AND INDIVIDUAL ORDERS DELIVERY, CATERING &amp; GROUP ORDERING, MANY OTHER PRODUCTS, LOOK NO FURTHER</span></p>\r\n<p>\r\n	<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- EACH ORDER IS MADE FRESH, EVERY MORNING, AND JUST THE WAY YOU WANT IT</span></p>\r\n<p>\r\n	<img alt=\"\" src=\"http://www.corporatecateringonline.com/images/mission.png\" style=\"width: 971px; height: 71px; \" /></p>\r\n<p>\r\n	<span style=\"font-family: verdana, geneva, sans-serif; font-size: 14px; \"><span style=\"color:#b22222;\"><strong>OUR VISION</strong></span>&nbsp;is to set higher standards, and open new prospective in Food Delivery industry. We see future where people in need are not being taken advantage of by either being charged inadequate delivery fees, required to minimum order, or forced to eat unhealthy and often food from mistrustful mobile facilities...&nbsp;We see our effort as moving forward, toward better standards in both, food choice and delivery service. Or as we like to say: We will work hard to bring back dignity to the word CATERING, and to make everyone think twice before they use it to describe their services. We will work hard to set new, better standards and to fulfill our mission.</span></p>\r\n<p>\r\n	<span style=\"color:#b22222;\"><font face=\"arial, helvetica, sans-serif\" size=\"3\"><b>STAY HEALTHY AND PRACTICE HEALTHY LIFE STYLE WITH CCOL&nbsp;</b></font></span></p>\r\n<p>\r\n	<span style=\"font-size: 14px; font-family: tahoma, geneva, sans-serif; \"><img alt=\"\" src=\"http://www.corporatecateringonline.com/images/upload/img_20122315141755.jpg\" style=\"float: right; width: 350px; height: 250px; \" />- &quot;WE ARE WHAT WE EAT&quot; it has been said, THAT&#39;S WHY <strong>WE OFFER HEALTHIER OPTIONS AND BETTER FOOD QUALITY</strong></span></p>\r\n<p>\r\n	<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">-GOOD FOOD MEANS LESS FRUSTRATION AND BETTER THINKING AND DECISION MAKING PROCESS</span></p>\r\n<p>\r\n	<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- EVERYONE THINKS BETTER AND PERFORMS BETTER AT WORK IF NOT HUNGRY, WITH CCOL YOU WILL NEVER NEED TO WORRY ABOUT YOUR LUNCH OPTIONS</span></p>\r\n<p>\r\n	<span style=\"font-size: 14px; font-family: tahoma, geneva, sans-serif; \">- OUR RECIPES ARE MADE IN PERFECT NUTRITIONAL BALANCE AND MODERATE CALORIE VALUE, SO AFTER YOUR LUNCH BREAK YOU WILL NOT FEEL TIRED AND SLEEPY</span></p>\r\n<p>\r\n	<span style=\"font-family: tahoma, geneva, sans-serif; font-size: 14px; \">- WE OFFER LIGHT AND HEALTHY OPTIONS, AND ALL OUR FOOD ITEMS ARE MADE FROM ALL FRESH AND BEST QUALITY INGREDIENTS</span></p>\r\n<p>\r\n	<span style=\"font-size: 14px; font-family: tahoma, geneva, sans-serif; \">- WITH BETTER FOOD CHOICES YOU WILL FEEL BETTER, MORE ENERGIZED, AND READY TO COPE WITH MANY CHALLENGES AT WORK AND TASKS WITHIN YOUR EVERYDAY ROUTINE</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<h2 style=\"text-align: center; \">\r\n	<span style=\"color:#b22222;\"><span style=\"font-size: 22px; \">THE BEST WAY TO PLAN YOUR DAY!</span></span></h2>\r\n'),
	(3,'faq','<h2 style=\"text-align: center; \">\r\n	Frequently Asked Questions&nbsp;</h2>\r\n<ul>\r\n	<li>\r\n		<a href=\"#qs1\">Why is this service different than other websites that also offer online food ordering?</a></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<a href=\"#qs2\">How would I know if I qualify for free delivery?</a></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<a href=\"#qs3\">Is my delivery really free?</a></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<a href=\"#qs4\">Do I need to register and what are the benefits if I do?</a></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<a href=\"#qs5\">What is the difference between Meal-Salad and Regular, or side salad?</a></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<a href=\"#qs6\">Can I order food for some other days, or just for next day delivery?</a></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<a href=\"#qs7\">How do I cancel my order if something happen and I need too?</a></li>\r\n</ul>\r\n<ul>\r\n	<li>\r\n		<a href=\"#qs8\">My coupon is not working, what should I do?</a></li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n</p>\r\n<h2>\r\n	Why is this service different than other website that also offer online food ordering?&nbsp;</h2>\r\n<p>\r\n	With other websites you will be charged for delivery multiple times. Restaurants will charge you (most likely $3.99) their own delivery fee, and the website company will also charge you their middleman service (usually $5.99). On top of that, most of the restaurants have minimum order requirements between $20-$40, depends on the restaurant. Plus there are certain limitations that apply, and your order may be rejected by the restaurant. Their delivery time may vary, and there are many other reasons why other online based ordering services are highly inconvenient... With Corporate Catering Online your delivery is absolutely FREE, and we don&#39;t require minimum order. You can fully customize your order, and send a direct message to our kitchen, so your meal is made exactly the way you prefer. Other than that, we have amazing selection of meals, so you won&#39;t need to worry about finding your favorite dish. Your order will be labeled and delivered with your name and custom notes on it.&nbsp;</p>\r\n<p>\r\n</p>\r\n<h2>\r\n	How would I know if I qualify for free delivery?</h2>\r\n<p>\r\n	All you need to do is to enter your location/company&#39;s name where prompted on the home page of this website. If you know about our service, you most likely are qualified for free delivery. All steps from there are pretty self explanatory as we tried to simplify customization and ordering process.</p>\r\n<p>\r\n</p>\r\n<h2>\r\n	Is my delivery really free?</h2>\r\n<p>\r\n	Yes. Delivery is absolutely free for all lunch box orders made through our website. And we don&#39;t require minimum order, as well. You can order only one item, regardless of the price, and we will still deliver it for free. Our unique concept and business model is based on delivery time scheduling, so that way we can afford to deliver to you for FREE.&nbsp;</p>\r\n<p>\r\n</p>\r\n<h2>\r\n	Do I need to register and what are the benefits if I do?</h2>\r\n<p>\r\n	We recommend to all our customers to register. Benefits of creating an account are free foods, discounts, promotion, and many yearly contests that will qualify you for valuable rewards with any purchase. Our policy clearly states that your account information will not be sold, disclosed, or used for any other purposes than for the purpose of this website.</p>\r\n<p>\r\n</p>\r\n<h2>\r\n	What is the difference between Meal Salad and Regular Salad?</h2>\r\n<p>\r\n	Meal salads are still salads, but made as full meals. All meal-salads are made with full portion of meat (eg. whole Chicken breast, steak or salmon filet, etc.), and these types of salads include a small side, which will make it a meal, and it&#39;s usually slice or roll of bread with butter, or for example in some cases rice, or side (deli) salad. Meal &quot;in our book&quot; doesn&#39;t mean that you will receive soda and fries along with it... Regular salads from another hand are little less in size, with sliced or diced meat choice, and could be ordered as addition to a sandwich, wraps, or any other item from our Menu. Regular salads are also decent size meals, but with meal-salad your are getting better value for the dollar. The idea behind meal-salads is also to have full meal, in terms of nutrition and calorie values, and a salad that will keep you full, but while you&#39;re still eating something light. So far, we had great feedbacks and respond on it and it is highly recommended option. In addition to this, you can also check our Side orders, which are smaller size deli containers and salads, that are recommended as a side to your other orders.</p>\r\n<p>\r\n</p>\r\n<h2>\r\n	Can I order food for any other day, or just for next day delivery?</h2>\r\n<p>\r\n	Yes. On the checkout process you will be asked to choose if you would like your food to be delivered next day, or any other day of the week. In case that you wish your delivery for any other day, please go to the calendar and select desired delivery date. In case that for your delivery location we have two delivery times scheduled (breakfast and lunch) please make sure that you specified preferred delivery time, as well. You lunch will be there every day of the week, if you wish to, and exactly at the scheduled &nbsp;time.</p>\r\n<p>\r\n</p>\r\n<h2>\r\n	How do I cancel my order, If something happened?</h2>\r\n<p>\r\n	No changes or cancelations could be made on line. So please make sure that you contact us over the phone at least 24 hours before your scheduled delivery date so we can cancel your order. In that case we will be able to give you credit for your next order. Please call 949-945-7702 and our representative will help you wit the process. Don&#39;t forget that our representatives are available MON - FRI from 9:00AM to 5:00PM. We will be more than happy to help you with cancelation. However, please note that there will be a cancelation fee of $3.00 (only to cover bank fees, which are non refundable to us).</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n</p>\r\n<h2>\r\n	My coupon is not working, what should I do?</h2>\r\n<p>\r\n	If your coupon is not working you will need to call our general number (949-945-7702) or to email us at info@corporatecateringonline.com with RE: Request for a coupon replacement as an email title. We will replace your coupon in 3-5 business day. Please also include non-working coupon code and date stamped on it, or date when you received or from us. Our high security web system may prevent some coupons to be used twice, or more times.</p>\r\n'),
	(4,'terms-and-policies','<h2 style=\"text-align: center; \">\r\n	Terms and Policies</h2>\r\n<h2>\r\n	<span style=\"font-size:16px;\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><strong>SINGLE LUNCH BOX ORDERS - Free Delivery</strong></span></span></h2>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">To verify if you are qualified for FREE DELIVERY, please go to the home-page of this website and enter the name of your company (and address if needed) where prompted. If qualify, you can proceed with order and you will be offered to register and create an account.&nbsp;We highly recommend everyone to register.&nbsp;Only registered users will be eligible for FREE DELIVERY, and to use/receive additional discounts, promotions, and coupons. Your information will not be disclosed, shared, sold or leased to someone else, and it will be used only for the purposes of this website. To protect your personal information from unauthorized access and use, we use security measures that comply with Federal laws.&nbsp;</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><strong style=\"font-family: verdana, geneva, sans-serif; \">Enjoy 100% money back guaranty and satisfaction policy.</strong><span style=\"font-family: verdana, geneva, sans-serif; \">&nbsp;In certain cases purchase will not be refundable, so</span><strong style=\"font-family: verdana, geneva, sans-serif; \"> please read&nbsp;General Terms and Conditions of Website Use Agreement thoroughly</strong><span style=\"font-family: verdana, geneva, sans-serif; \">, and make sure that you fully understand all Terms &amp; Policies and requirements that apply for FREE DELIVERY including money back policy.&nbsp;</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family: verdana, geneva, sans-serif; \">All orders placed trough this website will be delivered to your place of work (your company&#39;s address) to a prearranged pick up location. This location is determined by Customer&#39;s Office Manager, HR department, other individual who may be related to this matter, or majority of employees at your business location who are using our services. If not previously informed, please contact some of them to learn about pick up spot for your location.&nbsp;</span><u style=\"font-family: verdana, geneva, sans-serif; \">NOTE</u><span style=\"font-family: verdana, geneva, sans-serif; \">: CCOL is not responsible for any event that occurs after our Delivery personnel leaves the building/delivery location and&nbsp;</span><u style=\"font-family: verdana, geneva, sans-serif; \">money back 100% satisfaction policy will not apply for such claims and events</u><span style=\"font-family: verdana, geneva, sans-serif; \">. So please make sure that you check &quot;delivery notification option&quot; at the checkout process, and that you are signed up to your company&#39;s internal email list, since this method will be used as a general delivery notification system, and to avoid any interruption and service disturbance. WE GUARANTY THAT ALL ORDERS WILL BE DELIVERED IN POPPER TIMELY MANNER, OR YOU CAN ASK FOR REFUND.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family: verdana, geneva, sans-serif; \">When using our website (&quot;Service&quot;), you may review food, beverage, and other products offered, and place an order for each one of them to be delivered to you. Upon completing your order online CCOL will review your order and acknowledge receipt with an e-mail message that will be sent to your submitted e-mail address. Please note that your order will be finalized and accepted after the completion of check out process, where you will be prompted to enter your personal and credit or debit card information, and to make a payment for items ordered. The execution of your order and the charge to your credit card will be verified with an e-mail sent to you, and that will be deemed as the confirmation and the acceptance of your order.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Prices are subject to change without notice.</span></span></p>\r\n<h2>\r\n	<span style=\"font-size:16px;\"><span style=\"font-family:tahoma,geneva,sans-serif;\"><strong>CATERING ORDERS</strong></span></span></h2>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family: verdana, geneva, sans-serif; \">To place an <u>on line Catering order</u> you would need to have a Corporate Account opened and to be a registered user.&nbsp;</span><span style=\"font-family:verdana,geneva,sans-serif;\">Catering and Group orders, placed on line, are subjects to flat delivery rate charge of $30 plus local sales tax (exe. 7.75% for Orange County, California). Please note that for all&nbsp;<strong>non-online catering orders</strong>&nbsp;minimum of 24-hours advanced notice is required, and that there is 15% delivery and service charge, plus local tax, included in each&nbsp;<strong>non-online catering order</strong>&nbsp;invoice. This is not a gratuity charge. However, gratuity and tips should be added only if you are satisfied with the overall food and service quality.&nbsp;</span><span style=\"font-family: verdana, geneva, sans-serif; \">We will do our best to accommodate last minute requests, but please try to place all non-online catering orders at least 24 hours in advance.&nbsp;</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Prices for Catering menu and services are subject to change without notice.</span></span></p>\r\n<p>\r\n	<span style=\"color:#ffa500;\"><strong style=\"font-family: tahoma, geneva, sans-serif; font-size: 16px; \">GENERAL TERMS &amp; CONDITIONS OF WEBSITE USE AGREEMENT</strong></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Please read our General terms and conditions (&quot;Terms&quot;&nbsp;or&nbsp;&quot;Terms of Use&quot;) carefully, because they represent a binding agreement between you (&ldquo;Customer&rdquo;) and Corporate Catering Online (&ldquo;CCOL&rdquo;).</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">By accessing our website, and by using any of its services, you indicate that you understand and accept all Terms &amp; Conditions disclosed. If you do not agree with any or all of them please feel free to browse the website pages and content, but do not use any of our services. Also, you can always submit any questions that you may have regarding the Terms of Use to&nbsp;<a href=\"mailto:info@corporatecateringonline.com\">info@corporatecateringonline.com</a>, or refer to our FAQ page and try to find answers to your possible inquiry.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family: verdana, geneva, sans-serif; \">All orders placed trough this website will be delivered to prearranged pick up location. This location is determined by Customer&#39;s Office Manager, HR department, other individual who may be related to this matter, or majority of employees at your business location who are using our services. If not previously informed, please contact some of them to learn about pick up spot for your location.&nbsp;</span><u style=\"font-family: verdana, geneva, sans-serif; \">NOTE</u><span style=\"font-family: verdana, geneva, sans-serif; \">: CCOL is not responsible for any event that occurs after our Delivery personnel leaves the building/delivery location and&nbsp;</span><u style=\"font-family: verdana, geneva, sans-serif; \">money back 100% satisfaction policy will not apply for such claims and events</u><span style=\"font-family: verdana, geneva, sans-serif; \">. So please make sure that you check &quot;delivery notification option&quot; at the checkout process, and that you are signed up to your company&#39;s internal email list, since this method will be used as a general delivery notification system, and to avoid any interruption and service disturbance. WE GUARANTY THAT ALL ORDERS WILL BE DELIVERED IN POPPER TIMELY MANNER, OR YOU CAN ASK FOR REFUND.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family: verdana, geneva, sans-serif; \">When using our website (&quot;Service&quot;), you may review food, beverage, and other products offered, and place an order for each one of them to be delivered to you. Upon completing your order online CCOL will review your order and acknowledge receipt with an e-mail message that will be sent to your submitted e-mail address. Please note that your order will be finalized and accepted after the completion of check out process, where you will be prompted to enter your personal and credit or debit card information, and to make a payment for items ordered. The execution of your order and the charge to your credit card will be verified with an e-mail sent to you, and that will be deemed as the confirmation and the acceptance of your order.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family: verdana, geneva, sans-serif; \">Prices are subject to change without notice.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Availability</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Our online ordering services are available only to the employees of the companies where we previously made a delivery arrangement, and may only be used by individuals who work in such companies. We also can only provide our services to adults that can be legally bound by contracts under the applicable law. Each user of the Website must be a holder of valid credit or debit card and need to provide us with a valid e-mail address for contact purposes.&nbsp;Corporate Catering Online services are available for all major credit and debit card types.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Registration and user account</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Certain services of our website are available to registered users only. If you wish to place an order, you will be asked to first verify your delivery location, and then to open a user account. The registration is completely free and it enables you to order food online and receive information about discounts, special offers, and&nbsp;</span><span style=\"font-family: verdana, geneva, sans-serif; \">new services available.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">BY REGISTERING OR PLACING AN ORDER ONLINE YOU REPRESENT AND WARRANT THAT YOU ARE 18 YEARS OF AGE OR OLDER.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">When you register CCOL will ask you to provide certain contact and personal details, such as your full name, a valid e-mail address and a password and then provide additional details, such as credit or debit card details, and delivery and billing address (including address, city, state, country and zip/postal code). Bear in mind that false, incorrect, or out dated information may prevent you from registering and impair the ability to provide you with the services, or/and to contact you. CCOL will clearly indicate the fields for mandatory completion. If you do not enter the necessary data in these fields, you will not be able to register for our service.<br />\r\n	To login, you must use your personal code (such as: email address and password). You agree to maintain your access code in absolute confidentiality and refrain from disclosing it to others. Make sure that you change your password frequently and at least once every six months. If you forget your access code, CCOL will provide you with means to change it.<br />\r\n	You are fully accountable for any outcome that may result from your failure to provide complete details in the course of the registration process, from your failure to keep your account details in confidence, and for any use or misuse of your account on the Website as a result of conveying your details to someone else.<br />\r\n	You may terminate your account at any time, by sending a request for termination at <a href=\"mailto:info@corporatecateringonline.com\">info@corporatecateringonline.com</a>. CCOL may require you to verify your termination notice by sending an additional termination request message, either by e-mail or through any other means, as a precondition for terminating your account. Your account will terminate 7 days following your notification, and from that date of termination you will no longer be able to use our service or access your account.<br />\r\n	Notwithstanding any remedies that may be available under any applicable law, CCOL may temporarily or permanently deny, limit, suspend, or terminate your user account, prohibit you from accessing, or/and take technical and legal steps to keep you off our website, and this will happen if CCOL believes that -</span></span></p>\r\n<ul>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">you have abused your rights to use the website; or</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">you have breached these Terms; or</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">you deliberately submitted false information; or,</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">you have performed any act or omission that violates any applicable law, rules, or regulations; or,</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">you have performed any act or omission which is harmful or likely to be harmful to CCOL, or any other third party, including other users and suppliers of CCOL; or,</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">you made use of our website to perform an illegal act, or for the purpose of enabling, facilitating, assisting or inducing the performance of such an act; or,</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">you conveyed your account access code to another person.</span></span></p>\r\n	</li>\r\n</ul>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Charges and Payments</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">The current prices of all of the items posted on our website are provided by CCOL, and all of them are subject to change without notice. CCOL also holds the right to change the delivery rates and availability of any item in our menu without prior notice. All prices are stated in U.S. Dollars. Any changes in any prices and rates will take effect immediately after being posted on our website.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">You represent and warrant that you will pay full price (and if needed taxes) in a timely manner and as confirmation of your online ordering. Failing to settle your payments may prevent you from receiving your order, and further using our website, notwithstanding any other remedies available to CCOL under the applicable law.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Privacy</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">CCOL fully respects your privacy. CCOL does not knowingly collect any personally identifiable information without your consent. To place an order, you will be asked to register and provide personal details such as your full name, a valid e-mail address and a password and then provide additional details such as complete credit or debit card details and billing address (including address, city, state, country and zip/postal code).<br />\r\n	Further personally identifiable information may be collected when CCOL exchanges communications with you through the contact page, for example, if you submit an inquiry to the customer support.<br />\r\n	Please note that e-mail communication may not be secured, and therefore you should not provide us with credit or debit card details in your e-mail messages sent to us.<br />\r\n	When you use our services CCOL may use various legal and technologically accepted measures to collect information about your habits and store such information in web server log files, to maintain and enhance the quality of online services offered only, and to customize your experience. For example, CCOL may record the frequency and scope of your use of the Services, the duration of your sessions, the web pages that you visit, the information that you read, food and dining preferences, advertisements that you view or click on, whether you have visited the Services before, the Internet Protocol (IP) address that you use to access the Services, the geographic location of the computer system that you are using to sign-in or use the services and the browser and operating system that you use, and all with purpose to get statistically presented picture of how to improve its own services.<br />\r\n	CCOL may collect and organize such information either by itself or by a third party services (e.g., Google Analytics) for CCOL&rsquo;s internal purposes, such as tracking on number of visitors, products viewed, categories viewed, general online sales, sales of specific products, etc.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>What CCOL do with your personal information?</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">CCOL does not disclose your personal information to any third party. But CCOL may use your personal information for the following purposes:</span></span></p>\r\n<ul>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to provide you with better services and to enable you to use them;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to improve and customize your experience with the existing services;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to develop and improve new services;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to better learn and understand what services and products customers prefer;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to provide you with support, assistance and updates;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to handle inquiries, complaints and to collect payments;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to send you updates and notices, to provide you with information relating to the services and to provide you with further marketing and advertising material, such as information about new services that may interest you, subject to your prior indication of consent;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to facilitate communication between you and CCOL;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to conduct surveys from time to time;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to enforce the Terms of Use of the Services Terms of Use ;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to contact you as and when CCOL believes it to be necessary;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to comply with any applicable law and assist law enforcement agencies as required;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to collect fees and debts, and to prevent fraud, misappropriation, infringements, identity thefts and any other misuse of our online ordering services;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">to take any action in any case of dispute, or legal proceeding of any kind between you and us, or between you and other users or third parties with respect to, or in relation with our website and services;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">For any other purpose stipulated in this policy, or in the Terms of Use.</span></span></p>\r\n	</li>\r\n</ul>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>When can possibly CCOL share information with others</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">CCOL does not sell, rent or lease your personally identifiable information to third parties for any of their marketing purposes. CCOL may share personally identifiable information with others in any of the following instances or <u>subject to your explicit consent:</u></span></span></p>\r\n<ul>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">If CCOL reasonably believes that you have breached the Terms of Use, or abused your rights to use our website services, or performed any act or omission that CCOL reasonably believes to be violating any applicable law, rules, or regulations. In these cases, CCOL may share your information with law enforcement and other competent authorities, and with any third party, as may be required to handle any result of your wrongdoing;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">If CCOL is required, or reasonably believes that is required by law to share or disclose your information;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">In any case of dispute, or legal proceeding of any kind between you and us, or between you and other users or third parties with respect to, or in relation with the Services;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">In any case where CCOL may reasonably believe that sharing information is necessary to prevent imminent physical harm or damage to property;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">If CCOL organizes the operation of the Services within a different framework, or through another legal structure or entity, or if CCOL is acquired by, or merged with another entity, provided however, that those entities agree to be bound by the provisions of this policy, with respective changes taken into consideration;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">CCOL may also share personally identifiable information with companies or organizations directly connected, or directly affiliated with CCOL, such as legal subsidiaries, sister-companies and parent companies, with the express provision that their use of such information <u>must comply with this policy</u>.</span></span></p>\r\n	</li>\r\n</ul>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Intellectual Property</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">The Intellectual Property rights of our website and online services, including copyrights, trademarks, trade names, patents, trade secrets, and work methods, and any other rights, are the sole property of CORPORATE CATERING ONLINE and GRAL, LLC, or of third parties by whom CCOL and GRAL, LLC were licensed according to law. These rights apply, among others, to any textual and non-textual information, including menus, images, graphic design, online services offered, data and its processing, our website&#39; computer code(s) and any other detail concerning its operation.<br />\r\n	You may not copy, duplicate, distribute, sell, market, and translate any information, including trademarks, images, pictures, texts and computer code from our website, without receiving CCOL&rsquo;s explicit prior consent in writing.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Trademarks appearing on our website (whether registered or not), the name of CORPORATE CATERING ONLINE, as well as the Website&#39;s Domain name &ndash; are the sole property of CCOL. You may not use them without CCOL&rsquo;s written consent.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">All the information in this section (Intellectual Property) including but not limited to: copyrights, trademarks, trade names, patents, trade secrets, and work methods (recipes, clients&rsquo; contact information, customers&rsquo; personal information, ways of communication and doing business in general on and of the website) are considered to be a Confidential Information, and the rest of our employees, patrons, owners and their families depends on this information, and is such confidential information is disclosed to any third party without the consent and knowledge of suitable CCOL&rsquo;s representative, CCOL holds the right to take legal action in order to recover all occurred and any possible damages.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong style=\"font-family: verdana, geneva, sans-serif; \">This Website is not directed to children under the age of 18&nbsp;</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">If you are a child under the age of 18 years old, you may browse the content of our website, but you may not place an order online or provide CCOL with any personally identifiable information.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Acceptable use of the Website</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Subject to these Terms you may access and use our website, create an account, and order food online.&nbsp;The following Terms define the acceptable use of the Website. While using the Website you agree to refrain from willfully, or carelessly:</span></span></p>\r\n<ul>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Interfering with or disrupting the functionality of the Website;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Violating any applicable local, state, national or international law, statute, ordinance, rule or regulation;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Impersonating any person or entity, or making any false statement about your identity, employment, agency or affiliation with any person or entity;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Providing false or misleading credit card details and/or false delivery address when placing an order online;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Displaying the Website or any part thereof in an exposed or concealed frame;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Linking to certain elements on the Website independently from the web pages on which they originally appear;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Email, transmit or otherwise make available any information and materials that infringes third party&rsquo;s rights, including our Intellectual Property Rights;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Email, transmit or otherwise make available software viruses, Trojan horses, warms and any other malicious application to computers and networks;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Email, transmit or otherwise make available any information or material which may constitute or encourages conduct that would be constitute a criminal offense or civil wrong doing or otherwise violets any applicable law;</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Email, transmit or otherwise make available any information or material which may be deemed threatening, abusive, harassing, defamatory, libelous, vulgar, obscene or racially, ethnically or otherwise objectionable.</span></span></p>\r\n	</li>\r\n	<li>\r\n		<p>\r\n			<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Disobey or breach these Terms or any other applicable instructions conveyed by CCOL and its officers, patrons, representatives, and owners.</span></span></p>\r\n	</li>\r\n</ul>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Termination of operation</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">CCOL may at all times, in its sole discretion, terminate the operation of our website, or any part thereof, temporarily or permanently. CCOL may not give any notice prior to the termination of our website. At any time, certain content or a service may be blocked, removed or deleted without maintaining any backup copy. You agree and acknowledge that CCOL does not assume any responsibility with respect to, or in connection with the termination of our website&#39;s operations and loss of any data as a result.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Amendments to the Terms</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">CCOL may from time to time change the Terms, including any and all documents, forms and policies incorporated thereto. Substantial changes will take effect 30 days after an initial notification was posted on our website&#39;s homepage, or any other relevant web pages on our website. Other changes will take effect 7 days after their initial posting on our website, unless the Terms are amended to comply with legal requirements, where in such cases the amendments will become effective as required, or ordered, by law.<br />\r\n	You agree to be bound by any of the changes made in all Terms and Conditions of this website, including changes to any and all documents, forms and policies incorporated thereto. Continuing to use the Website will indicate your acceptance of the amended terms. If you do not agree with any of the amended terms, then you must avoid any further use of this website.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Changes and Availability</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">CCOL may from time to time change its website&rsquo;s structure, layout, design or display, as well as the scope and availability of the information and content therein, without giving any previous notice. Changes of this type by their very nature are likely to result in glitches or cause inconvenience of some kind. You shall not have any plea, claim or demand whatsoever against CCOL ensuing from the introduction of aforesaid changes or from glitches or any kind of failure resulting from their introduction. The CCOL&rsquo;s website as it is depends on different factors such as software, hardware and communication networks (internet, etc), and its contractors and suppliers. By their nature, these factors are not fault free or tolerant, hereafter CCOL can&#39;t guarantee that the website will not be disturbed, will be timely, secure or error free.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Disclaimer of Warranty</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">YOU ACKNOWLEDGE AND AGREE THAT THIS WEBSITE IS BEING PROVIDED FOR USE &quot;AS IS&quot;, AND THEREFORE YOU WILL NOT HAVE ANY PLEA, CLAIM OR DEMAND VIS-A-VIS CCOL IN RESPECT OF THE WEBSITE&#39;S PROPERTIES, ABILITIES, LIMITATIONS OR COMPATIBILITY WITH YOUR NEEDS. THE USE OF THE WEBSITE IS ACCORDINGLY BEING MADE AT YOUR SOLE AND WHOLE RISK, WITHOUT WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, NON-INFRINGEMENT, COMPATIBILITY, SECURITY OR ACCURACY.<br />\r\n	CCOL DOES NOT WARRANT THAT THE WEBSITE WILL OPERATE IN AN UNINTERRUPTED OR ERROR-FREE MANNER OR THAT THE WEBSITE IS ALWAYS FREE FROM ALL HARMFUL COMPONENTS. USE OF INFORMATION OR CONTENT OBTAINED FROM OR THROUGH OUR WEBSITE IS AT YOUR OWN RISK.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Governing Law, Jurisdiction</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">These Terms will be governed by and construed in accordance with the laws of the State of California.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Severability</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">If any provision of the Terms is held to be illegal, invalid, or unenforceable by a competent court, then the provision will be performed and enforced to the maximum extent permitted by law, and the remaining provisions of the Terms will continue to remain in full force and effect.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>General</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">The Terms and Conditions constitute the entire agreement between you and CCOL with respect to the use of our website and the services therein.<br />\r\n	No waiver, concession, extension, representation, alteration, addition, or derogation from the Terms by CCOL, or pursuant to the Terms, will be effective unless consented explicitly and executed in writing by CCOL&#39;s authorized representative.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">The Terms and Conditions will take precedence over all documents, forms and policies incorporated thereto, which may conflict with these Terms, unless specifically indicated in such documents that a certain provision is determined notwithstanding any of the provisions of these Terms.<br />\r\n	Failure on CCOL part to demand performance of any provision in the Terms will not constitute a waiver of any of CCOL&rsquo;s rights under the Terms.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Changes in Ownership</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">CCOL may incorporate the ownership or management of the Website as a separate corporation, or transfer ownership rights and title of our website, to a third party, provided that your rights according to these Terms are not harmed by the transfer of rights. In that case, a copy of the details and information related to you will be transferred to the corporation receiving the rights in the website and you hereby give your prior consent thereto.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>No Assignment</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Your rights and obligations under the Terms are not assignable. Any attempted or actual assignment thereof by you will be null and void without CCOL&rsquo;s prior explicit and written consent.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\"><strong>Survival</strong></span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">The provisions of the intellectual property, disclaimer of warranty, limitation of liability and indemnification sections, will survive the termination, or expiration of the Terms.</span></span></p>\r\n<p>\r\n	<span style=\"font-size:12px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Last updated: [January, 2012]</span></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n'),
	(5,'contact-us','<h2 style=\"text-align: center; \">\r\n	Contact us&nbsp;</h2>\r\n<h2 style=\"text-align: center; \">\r\n	Tel 949.945.7702 &nbsp; &nbsp; M-F 9:00AM-5:00PM</h2>\r\n<p>\r\n	If you enjoy our cooking and we are unable to deliver you can contact us and place a&nbsp;<strong>PICK -UP order</strong>. Thank you for&nbsp;being our customer.</p>\r\n'),
	(6,'request-a-quote','<h2 style=\"text-align: center; \">\r\n	NEED HELP FOR YOU NEXT EVENT? REQUEST A QUOTE...</h2>\r\n<p style=\"text-align: center; \">\r\n	<strong style=\"font-family: tahoma, geneva, sans-serif; \"><span style=\"font-size: 14px; \">To request a quote for your next event, please fill in and submit form below. We will email you back with few tips, and our proposal of what we think it would be the best way to do it. You will get our best offer instantly.</span></strong></p>\r\n');

/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table photos
# ------------------------------------------------------------

DROP TABLE IF EXISTS `photos`;

CREATE TABLE `photos` (
  `idphotos` int(200) NOT NULL AUTO_INCREMENT,
  `photosImg` varchar(230) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idphotos`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
INSERT INTO `photos` (`idphotos`,`photosImg`)
VALUES
	(1,'img_20121224174255.jpg'),
	(10,'img_201222721141.jpg'),
	(3,'img_20121527235349.jpg'),
	(11,'img_20122315141755.jpg'),
	(6,'img_201221611381.jpg'),
	(7,'img_2012216123323.jpg'),
	(8,'img_2012216123336.jpg'),
	(9,'img_2012216123349.jpg');

/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table photosCcolCat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `photosCcolCat`;

CREATE TABLE `photosCcolCat` (
  `idphotosCcolCat` int(50) NOT NULL AUTO_INCREMENT,
  `photosCcolCatImg` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `idcateringfullCat` int(50) NOT NULL,
  PRIMARY KEY (`idphotosCcolCat`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `photosCcolCat` WRITE;
/*!40000 ALTER TABLE `photosCcolCat` DISABLE KEYS */;
INSERT INTO `photosCcolCat` (`idphotosCcolCat`,`photosCcolCatImg`,`idcateringfullCat`)
VALUES
	(8,'img_201221605232.jpg',1),
	(9,'img_201221605246.jpg',1),
	(10,'img_20122160530.jpg',1),
	(18,'img_20122160590.jpg',4),
	(17,'img_201221605840.jpg',4),
	(13,'img_20122160559.jpg',4),
	(14,'img_201221605656.jpg',5),
	(15,'img_201221605710.jpg',5),
	(16,'img_201221605720.jpg',5),
	(19,'img_2012216114.jpg',6),
	(20,'img_20122161124.jpg',6),
	(22,'img_20122161358.jpg',6);

/*!40000 ALTER TABLE `photosCcolCat` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table route
# ------------------------------------------------------------

DROP TABLE IF EXISTS `route`;

CREATE TABLE `route` (
  `routeId` int(100) NOT NULL AUTO_INCREMENT,
  `routeName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `driver` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`routeId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` (`routeId`,`routeName`,`driver`)
VALUES
	(1,'A2','New'),
	(2,'B','New'),
	(3,'C','New'),
	(4,'A','Jaimee'),
	(5,'ABCD','Daniel Dulic');

/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table routecomp
# ------------------------------------------------------------

DROP TABLE IF EXISTS `routecomp`;

CREATE TABLE `routecomp` (
  `routeCompId` int(200) NOT NULL AUTO_INCREMENT,
  `companyId` int(150) NOT NULL,
  `routeId` int(100) NOT NULL,
  `timeIn` time NOT NULL,
  `timeOut` time NOT NULL,
  PRIMARY KEY (`routeCompId`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `routecomp` WRITE;
/*!40000 ALTER TABLE `routecomp` DISABLE KEYS */;
INSERT INTO `routecomp` (`routeCompId`,`companyId`,`routeId`,`timeIn`,`timeOut`)
VALUES
	(42,5,5,'09:00:00','09:30:00'),
	(43,7,5,'10:00:00','10:30:00'),
	(44,1,5,'11:00:00','11:30:00');

/*!40000 ALTER TABLE `routecomp` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table slider
# ------------------------------------------------------------

DROP TABLE IF EXISTS `slider`;

CREATE TABLE `slider` (
  `idSlider` int(5) NOT NULL AUTO_INCREMENT,
  `filenameSlider` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `titleSlider` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `descSlider` text COLLATE utf8_unicode_ci NOT NULL,
  `readMore` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idSlider`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `slider` WRITE;
/*!40000 ALTER TABLE `slider` DISABLE KEYS */;
INSERT INTO `slider` (`idSlider`,`filenameSlider`,`titleSlider`,`descSlider`,`readMore`)
VALUES
	(2,'img_201112011683.jpg','WHY CCOL (ABOUT US)','We are not middleman between you and the restaurants. Our delivery is absolutely FREE, and NO MINIMUM ORDER is required. We make fresh and delicious food in our 5,000 sq ft fully equipped kitchen facility, and with our professional staff we are ready to take on any task.  ','http://corporatecateringonline.com/index.php?page=why-ccol'),
	(10,'img_20122161592.jpg','CHECK OUT OUR FULL OFFER','You will be pleasantly surprised to see our full offer. Don\'t miss out, check our Desserts and Beverages sections. Fully customize all your orders, add anything from whole fresh fruits to variety of healthy snacks. Enjoy our FREE DELIVERY and NO MINIMUM ORDER service. ','http://corporatecateringonline.com/index.php?page=lunch-box-menu'),
	(11,'img_20122162411.jpg','WE ALSO PROVIDE FULL CORPORATE CATERING SERVICE','From small meetings to large Corporate Events. Find it all at one place. Affordable prices, delicious food, and professional and accurate delivery service. Enjoy convenience of our easy to use on-line ordering system, and save yourself some time and money.','http://corporatecateringonline.com/index.php?page=catering-menu'),
	(20,'img_20122416184711.jpg','WE MAKE GREAT CORPORATE EVENTS EVEN BETTER...','Have a long meeting, or an event to host? No time for shopping around and to call different caterers... You can always try our easy to use online ordering system, or try requesting a quote and we\'ll send you our best offer instantly. \r\n','http://corporatecateringonline.com/index.php?page=request-a-quote');

/*!40000 ALTER TABLE `slider` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table subcat
# ------------------------------------------------------------

DROP TABLE IF EXISTS `subcat`;

CREATE TABLE `subcat` (
  `idSubcat` int(15) NOT NULL AUTO_INCREMENT,
  `catId` int(10) NOT NULL,
  `subcatName` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `subcatDetails` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idSubcat`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `subcat` WRITE;
/*!40000 ALTER TABLE `subcat` DISABLE KEYS */;
INSERT INTO `subcat` (`idSubcat`,`catId`,`subcatName`,`subcatDetails`)
VALUES
	(1,4,'Testname 12','Description of the subcategory. 312'),
	(2,0,'testt','tterer'),
	(3,0,'tetete','tetetetststs'),
	(5,5,'teteastete','tetetetetwtstsetest s thf'),
	(6,0,'tester2','tehhtekhtkjhjk tkjsegtkjesktlgshejkl');

/*!40000 ALTER TABLE `subcat` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `idUser` int(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `secondname` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `registerdate` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idUser`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`idUser`,`username`,`password`,`email`,`firstname`,`secondname`,`registerdate`,`note`)
VALUES
	(6,'testuser','c80d1ff9e7eb2c65c31d5a0839b7902e','test@user.com','Test','User','12.12.2011. 11:35',''),
	(7,'gradimir','8e1072c5c824dec075bb47291efe616c','grada@corporatecateringonline.com','Gradimir','Lukić','19.01.2012. 22:36','');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table usersFE
# ------------------------------------------------------------

DROP TABLE IF EXISTS `usersFE`;

CREATE TABLE `usersFE` (
  `idUser` int(200) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `fname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `companyName` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `zipCode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `companyId` int(40) NOT NULL,
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `newsletters` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `dateReg` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `ban` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `suite` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idUser`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `usersFE` WRITE;
/*!40000 ALTER TABLE `usersFE` DISABLE KEYS */;
INSERT INTO `usersFE` (`idUser`,`email`,`password`,`fname`,`lname`,`type`,`companyName`,`address`,`zipCode`,`companyId`,`telephone`,`fax`,`newsletters`,`dateReg`,`ban`,`city`,`suite`)
VALUES
	(1,'test@test.ts','e807f1fcf82d132f9bb018ca6738a19f','Daniel','Dulic','corporate','Nesk WebArt','Test Adress','24000',1,'+74646464568','+432847892','1','','','Subotica','100'),
	(2,'teh3@ht4k.te','202cb962ac59075b964b07152d234b70','Dnaen','fenkjfskj','corporate','Neskwebart','','fekuhkesfe',5,'efksf83923','979','1','13.02.2012. 06:10','','',''),
	(3,'daniel.dulic@neskwebart.com','e10adc3949ba59abbe56e057f20f883e','Test','tete','individual','','','',1,'0123456789+','9876543210+','1','13.02.2012. 09:10','','',''),
	(4,'g.trader@hotmail.com','070a53565ccdd4ded54a63a5ffc127cd','Gradimir','Lukic','individual','','','',5,'','','1','14.02.2012. 08:41','','',''),
	(5,'test@test.net','e10adc3949ba59abbe56e057f20f883e','Daniel','Dulic','individual','','','',1,'123456','123456','1','15.02.2012. 12:55','','',''),
	(6,'boris.teodosijevic@gmail.com','2fb2a7926ca34f84d85f7d40805d4d96','Boris','Teodosijevic','individual','','','',1,'+381641147124','','1','15.02.2012. 13:01','','',''),
	(8,'grada@corporatecateringonline.com','070a53565ccdd4ded54a63a5ffc127cd','gradimir','lukic','corporate','','','',5,'','','1','01.03.2012. 10:53','','',''),
	(9,'Boris.teodosijevic@neskwebart.com','2fb2a7926ca34f84d85f7d40805d4d96','Boris','Teodosijevic','corporate','Nesk WebArt','Road Town, British Virgin Islands','43169',0,'+381641147124','','','01.03.2012. 19:13','','Tortola','15/21'),
	(11,'gradalukic@yahoo.com','05f4c7f46069e5b874ff36f5f3810bde','Grada','Lukic','corporate','Gral, LLC','2148 Michelson','92612',0,'','949-757-1881','1','02.03.2012. 12:26','','',''),
	(10,'h@tr.ere','202cb962ac59075b964b07152d234b70','ffe','fesfs','corporate','test','terter','terre',0,'123','fesfs','1','01.03.2012. 21:15','','',''),
	(12,'lmcelroy@mobilityware.com','583133d57ed17a3cdf5212b6bee131f5','Lee','McElroy','individual','','','',0,'949-788-9900','','1','05.03.2012. 10:15','','',''),
	(18,'tom.palic.programming@gmail.com','85a4dd9f5b542b2b1b1b34a7fab3cbde','Tomislav','Palic','individual','','','',5,'','','1','16.03.2012. 14:57','','',''),
	(17,'ptomassss@gmail.com','85a4dd9f5b542b2b1b1b34a7fab3cbde','Tomislav','Palic','corporate','','','',5,'','','1','09.03.2012. 23:21','','','');

/*!40000 ALTER TABLE `usersFE` ENABLE KEYS */;
UNLOCK TABLES;





/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
