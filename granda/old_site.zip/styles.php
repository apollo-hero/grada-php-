<?PHP
	echo '<link href="style_v_3.css" rel="stylesheet" type="text/css" />';
?>