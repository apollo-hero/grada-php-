<?PHP
	phpinfo();
?>