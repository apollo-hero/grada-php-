======================================================================================================================
INTRODUCTION
======================================================================================================================
This PHP script creates an image with a security code (known as "captcha") that can be used to protect e.g. your
guestbook from spam. It requires PHP 4.1.0 or higher with session support and GD library.

Why create an image? The answer is simple: any text that appears on a web page (even in a hidden input field) can
be copied. In order to copy a text from an image you need special software (OCR), and even then you cannot be sure
that the software recognizes the characters correctly.

======================================================================================================================
LICENSE
======================================================================================================================
This script is freeware for non-commercial use. If you like it, please feel free to make a donation!
However, if you intend to use the script in a commercial project, please donate at least EUR 5.
You can make a donation on my website: http://www.gerd-tentler.de/tools/seccode/.

======================================================================================================================
USAGE
======================================================================================================================
Add an extra form field to your message form like this:

  <input type="text" name="secCode"> <b>&laquo;</b>
  <img src="seccode.php" width="71" height="21" align="absmiddle">

Sec-Code stores the security code in a session variable, so don't forget to start a session in your script where
you validate the security code. This has to be done before any headers are sent:

  if(!session_id()) session_start();

Here's an example how you can check for a valid security code:

  if($_POST['secCode'] != $_SESSION['secCode']) {
    // wrong security code
    ...
  }
  else {
    // security code is valid; reset it!
    $_SESSION['secCode'] = rand(100000, 999999);
    ...
  }

If the security code is valid, it should be resetted to make sure that it can't be used again.

Please also have a look at the included "example.php" file.

======================================================================================================================
Source code + example available at http://www.gerd-tentler.de/tools/seccode/.
======================================================================================================================
