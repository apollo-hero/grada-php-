<?
  if(!session_id()) session_start();

  header('Cache-control: private, no-cache, must-revalidate');
  header('Expires: 0');
?>
<html>
<head>
<title>Sec-Code Sample Page</title>
<style> <!--
BODY, P, SPAN, DIV, TABLE, TD, TH, UL, OL, LI {
  font-family: Arial, Helvetica;
  font-size: 14px;
  color: black;
}
--> </style>
</head>
<body marginwidth="10" marginheight="10" topmargin="10" leftmargin="10">
<center>
<?
  if($_POST['name'] && $_POST['subject'] && $_POST['message'] && $_POST['secCode']) {

    if($_POST['secCode'] != $_SESSION['secCode']) {
      // wrong security code
      echo '<font color="red"><b>WRONG CODE!</b></font>';
    }
    else {
      // security code is valid; reset it!
      $_SESSION['secCode'] = rand(100000, 999999);
      echo '<b>Thanx!</b>';
    }
?>
    <br><br>
    [<a href="<? echo $_SERVER['PHP_SELF']; ?>"><b>Go Back</b></a>]
<?
  }
  else {
?>
    <form action="<? echo $_SERVER['PHP_SELF']; ?>" method="post">
    <table border="0" cellspacing="0" cellpadding="4"><tr>
    <td><b>Name:</b></td>
    <td><input type="text" name="name" style="width:250px" value="<? echo $_POST['name']; ?>"></td>
    </tr><tr>
    <td><b>Subject:</b></td>
    <td><input type="text" name="subject" style="width:250px" value="<? echo $_POST['subject']; ?>"></td>
    </tr><tr valign=top>
    <td><b>Message:</b></td>
    <td><textarea name="message" wrap="virtual" style="width:250px; height:50px"><? echo $_POST['message']; ?></textarea></td>
    </tr><tr>
    <td><b>Code:</b></td>
    <td><input type="text" name="secCode" maxlength="6" style="width:50px"> <b>&laquo;</b>
    <img src="seccode.php" width="71" height="21" align="absmiddle"></td>
    </tr></table><br>
    <input type="submit" value="Submit">
    </form>
<?
  }
?>
</center>
</body>
</html>
